import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

function ticketCode() {
  return `VTX-${Math.random().toString(36).slice(2, 6).toUpperCase()}-${Math.random()
    .toString(36)
    .slice(2, 6)
    .toUpperCase()}`;
}

/** Creates a pending order and returns the Paystack checkout URL. */
export const startCheckout = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        eventId: z.string().uuid(),
        tierId: z.string().uuid(),
        quantity: z.number().int().min(1).max(10),
        callbackUrl: z.string().url(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const secret = process.env["PAYSTACK_SECRET_KEY"];
    if (!secret) {
      return {
        ok: false as const,
        error: "Payments aren't configured yet. Ask the organiser to connect Paystack.",
      };
    }

    const { data: tier, error: tierError } = await context.supabase
      .from("ticket_tiers")
      .select("id, price, available, event_id, name, events(currency, title)")
      .eq("id", data.tierId)
      .eq("event_id", data.eventId)
      .maybeSingle();

    if (tierError || !tier) return { ok: false as const, error: "Ticket type not found." };
    if (!tier.available) return { ok: false as const, error: "This ticket type is sold out." };

    const unitPrice = Number(tier.price);
    const total = unitPrice * data.quantity;
    const email = (context.claims["email"] as string | undefined) ?? "";
    if (!email) return { ok: false as const, error: "Your account has no email address." };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: order, error: orderError } = await supabaseAdmin
      .from("orders")
      .insert({
        buyer_id: context.userId,
        event_id: data.eventId,
        tier_id: data.tierId,
        quantity: data.quantity,
        unit_price: unitPrice,
        total,
        status: "pending",
        provider: "paystack",
        buyer_email: email,
      })
      .select("id")
      .single();
    if (orderError) return { ok: false as const, error: "Could not create your order." };

    const response = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${secret}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email,
        amount: Math.round(total * 100),
        callback_url: data.callbackUrl,
        metadata: { order_id: order.id, event_id: data.eventId },
      }),
    });

    const payload = (await response.json()) as {
      status?: boolean;
      message?: string;
      data?: { authorization_url?: string; reference?: string };
    };

    if (!response.ok || !payload.status || !payload.data?.authorization_url) {
      console.error("[paystack] init failed", payload.message);
      await supabaseAdmin.from("orders").update({ status: "failed" }).eq("id", order.id);
      return { ok: false as const, error: "Payment provider rejected the request." };
    }

    await supabaseAdmin
      .from("orders")
      .update({ provider_reference: payload.data.reference ?? null })
      .eq("id", order.id);

    return { ok: true as const, url: payload.data.authorization_url, orderId: order.id };
  });

/** Verifies a Paystack reference, marks the order paid and issues tickets. */
export const verifyCheckout = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ reference: z.string().min(4).max(120) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const secret = process.env["PAYSTACK_SECRET_KEY"];
    if (!secret) return { ok: false as const, error: "Payments aren't configured." };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: order } = await supabaseAdmin
      .from("orders")
      .select("id, buyer_id, event_id, tier_id, quantity, status")
      .eq("provider_reference", data.reference)
      .maybeSingle();

    if (!order || order.buyer_id !== context.userId) {
      return { ok: false as const, error: "Order not found." };
    }
    if (order.status === "paid") return { ok: true as const, orderId: order.id };

    const response = await fetch(
      `https://api.paystack.co/transaction/verify/${encodeURIComponent(data.reference)}`,
      { headers: { Authorization: `Bearer ${secret}` } },
    );
    const payload = (await response.json()) as {
      status?: boolean;
      data?: { status?: string };
    };

    if (!payload.status || payload.data?.status !== "success") {
      await supabaseAdmin.from("orders").update({ status: "failed" }).eq("id", order.id);
      return { ok: false as const, error: "Payment was not completed." };
    }

    await supabaseAdmin.from("orders").update({ status: "paid" }).eq("id", order.id);

    const { data: existing } = await supabaseAdmin
      .from("tickets")
      .select("id")
      .eq("order_id", order.id);

    if ((existing?.length ?? 0) === 0) {
      await supabaseAdmin.from("tickets").insert(
        Array.from({ length: order.quantity }, () => ({
          order_id: order.id,
          event_id: order.event_id,
          tier_id: order.tier_id,
          owner_id: order.buyer_id,
          ticket_code: ticketCode(),
        })),
      );
    }

    return { ok: true as const, orderId: order.id };
  });
