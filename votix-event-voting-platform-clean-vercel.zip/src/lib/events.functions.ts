import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";
import type { EventRow } from "@/data/events";

const SELECT =
  "id, slug, title, category, organizer_name, image_url, starts_at, ends_at, venue, city, currency, description, voting_status, voting_closes_at, ticket_tiers(id, name, description, price, available, position), vote_categories(id, name, position, vote_nominees(id, name, subtitle, votes))";

function publicClient() {
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
  const url = process.env["SUPABASE_URL"]!;
  return createClient<Database>(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) {
          h.delete("Authorization");
        }
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

export const listPublicEvents = createServerFn({ method: "GET" }).handler(async () => {
  const { data, error } = await publicClient()
    .from("events")
    .select(SELECT)
    .eq("published", true)
    .order("starts_at", { ascending: true });
  if (error) {
    console.error("[events] list failed", error.message);
    return { events: [] as EventRow[], error: "Could not load events right now." };
  }
  return { events: (data ?? []) as unknown as EventRow[], error: null };
});

export const getPublicEvent = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) => z.object({ slug: z.string().min(1) }).parse(input))
  .handler(async ({ data }) => {
    const { data: row, error } = await publicClient()
      .from("events")
      .select(SELECT)
      .eq("slug", data.slug)
      .eq("published", true)
      .maybeSingle();
    if (error) {
      console.error("[events] detail failed", error.message);
      return { event: null };
    }
    return { event: (row as unknown as EventRow | null) ?? null };
  });
