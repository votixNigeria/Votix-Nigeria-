import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, SiteLayout } from "@/components/site/SiteLayout";

export const Route = createFileRoute("/voting")({
  head: () => ({
    meta: [
      { title: "Voting — VOTIX" },
      {
        name: "description",
        content:
          "Cast your vote in live event polls, nominee categories and award shows with transparent, real-time results.",
      },
      { property: "og:title", content: "Voting — VOTIX" },
      {
        property: "og:description",
        content: "Live event polls and award categories with transparent real-time tallies.",
      },
    ],
  }),
  component: VotingPage,
});

function VotingPage() {
  return (
    <SiteLayout>
      <PageHeader
        eyebrow="Participate"
        title="Voting"
        description="Nominee categories, live polls and transparent real-time tallies. Open voting campaigns will appear here."
      />
      <div className="mx-auto max-w-7xl px-5 py-16 lg:px-8">
        <p className="text-muted-foreground">Voting campaigns coming soon.</p>
      </div>
    </SiteLayout>
  );
}
