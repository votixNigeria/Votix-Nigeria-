# VOTIX: Event & Voting Platform

Build the initial foundation of a modern event ticketing and voting platform called VOTIX.



Brand



- Name: VOTIX

- Tagline: "Tickets. Votes. Experiences."

- Design should feel modern, premium, trustworthy and energetic.

- Use a professional dark/white interface with a strong accent color.

- Make the website fully responsive for mobile, tablet and desktop.



Public homepage



Create:



1. VOTIX logo/name in the navbar

2. Home

3. Events

4. Voting

5. How It Works

6. Login

7. Sign Up

8. "Create an Event" CTA



Hero section:



- Headline: "Discover Events. Get Your Tickets. Make Your Vote Count."

- Short description explaining that VOTIX allows people to discover events, purchase digital tickets and participate in event voting.

- Buttons: Explore Events and Create an Event

