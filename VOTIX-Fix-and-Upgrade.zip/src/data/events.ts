/**
 * Shared event types + formatters.
 * Data now comes from the backend (see src/lib/events.functions.ts);
 * this module only holds the shapes and display helpers.
 */
import fallbackImage from "@/assets/hero-crowd.jpg";

export const EVENT_CATEGORIES = [
  "Concert",
  "Awards",
  "Conference",
  "Festival",
  "Other",
] as const;

export type EventCategory = string;

export type VotingStatus = "open" | "closed" | "none";

export interface TicketTier {
  id: string;
  name: string;
  price: number;
  description: string;
  available: boolean;
}

export interface VoteNominee {
  id: string;
  name: string;
  subtitle: string;
  votes: number;
}

export interface VoteCategory {
  id: string;
  name: string;
  nominees: VoteNominee[];
}

export interface EventRecord {
  id: string;
  slug: string;
  title: string;
  category: EventCategory;
  organizer: string;
  image: string;
  /** ISO 8601 start datetime. */
  startsAt: string;
  endsAt: string;
  venue: string;
  city: string;
  currency: string;
  description: string[];
  votingStatus: VotingStatus;
  votingClosesAt?: string | undefined;
  ticketTiers: TicketTier[];
  voteCategories: VoteCategory[];
}

/** Raw shape returned by the backend queries. */
export interface EventRow {
  id: string;
  slug: string;
  title: string;
  category: string;
  organizer_name: string;
  image_url: string | null;
  starts_at: string;
  ends_at: string | null;
  venue: string;
  city: string;
  currency: string;
  description: string;
  voting_status: string;
  voting_closes_at: string | null;
  published?: boolean;
  ticket_tiers?: Array<{
    id: string;
    name: string;
    description: string;
    price: number | string;
    available: boolean;
    position: number;
  }> | null;
  vote_categories?: Array<{
    id: string;
    name: string;
    position: number;
    vote_nominees?: Array<{
      id: string;
      name: string;
      subtitle: string;
      votes: number;
    }> | null;
  }> | null;
}

export function mapEvent(row: EventRow): EventRecord {
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    category: row.category,
    organizer: row.organizer_name || "VOTIX organiser",
    image: row.image_url || fallbackImage,
    startsAt: row.starts_at,
    endsAt: row.ends_at ?? row.starts_at,
    venue: row.venue,
    city: row.city,
    currency: row.currency || "₦",
    description: (row.description || "")
      .split("\n")
      .map((p) => p.trim())
      .filter(Boolean),
    votingStatus: (row.voting_status as VotingStatus) ?? "none",
    votingClosesAt: row.voting_closes_at ?? undefined,
    ticketTiers: [...(row.ticket_tiers ?? [])]
      .sort((a, b) => a.position - b.position)
      .map((t) => ({
        id: t.id,
        name: t.name,
        description: t.description,
        price: Number(t.price),
        available: t.available,
      })),
    voteCategories: [...(row.vote_categories ?? [])]
      .sort((a, b) => a.position - b.position)
      .map((c) => ({
        id: c.id,
        name: c.name,
        nominees: (c.vote_nominees ?? []).map((n) => ({
          id: n.id,
          name: n.name,
          subtitle: n.subtitle,
          votes: n.votes,
        })),
      })),
  };
}

export function startingPrice(event: EventRecord): number {
  const prices = event.ticketTiers.filter((t) => t.available).map((t) => t.price);
  if (prices.length === 0) return 0;
  return Math.min(...prices);
}

export function formatPrice(amount: number, currency = "₦"): string {
  return `${currency}${amount.toLocaleString("en-NG")}`;
}

export function formatEventDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-NG", {
    weekday: "short",
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export function formatEventTime(iso: string): string {
  return new Date(iso).toLocaleTimeString("en-NG", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function slugify(title: string): string {
  const base = title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 48);
  return `${base || "event"}-${Math.random().toString(36).slice(2, 7)}`;
}
