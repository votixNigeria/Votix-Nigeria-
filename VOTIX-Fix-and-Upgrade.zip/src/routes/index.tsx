import { createFileRoute, Link } from "@tanstack/react-router";
import { CalendarDays, MapPin, ShieldCheck, Ticket, Vote, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SiteLayout } from "@/components/site/SiteLayout";
import heroCrowd from "@/assets/hero-crowd.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VOTIX — Tickets. Votes. Experiences." },
      {
        name: "description",
        content:
          "Discover events, buy secure digital tickets and cast your vote in live event polls and award shows with VOTIX.",
      },
      { property: "og:title", content: "VOTIX — Tickets. Votes. Experiences." },
      {
        property: "og:description",
        content:
          "Discover events, buy secure digital tickets and cast your vote in live event polls and award shows.",
      },
    ],
  }),
  component: Index,
});

const featuredEvents = [
  {
    title: "Afro Future Live",
    category: "Concert",
    date: "Sat, Sep 12",
    location: "Eko Convention Centre, Lagos",
    price: "From ₦15,000",
  },
  {
    title: "Campus Awards Night",
    category: "Awards",
    date: "Fri, Sep 26",
    location: "Landmark Event Centre",
    price: "From ₦8,500",
  },
  {
    title: "Founders Summit 2026",
    category: "Conference",
    date: "Thu, Oct 08",
    location: "Civic Centre, Victoria Island",
    price: "From ₦25,000",
  },
];

const pillars = [
  {
    icon: Ticket,
    title: "Digital tickets",
    body: "Instant QR tickets delivered on purchase, scanned at the gate in seconds.",
  },
  {
    icon: Vote,
    title: "Live voting",
    body: "Run transparent nominee polls with real-time tallies your audience can trust.",
  },
  {
    icon: ShieldCheck,
    title: "Secure payments",
    body: "Protected checkout and verified organisers on every event listed.",
  },
  {
    icon: Zap,
    title: "Launch fast",
    body: "Publish an event page, ticket tiers and vote categories in minutes.",
  },
];

function Index() {
  return (
    <SiteLayout>
      <section className="relative isolate overflow-hidden">
        <img
          src={heroCrowd}
          alt="Crowd with raised hands at a concert lit by orange stage lights"
          width={1536}
          height={1024}
          className="absolute inset-0 -z-20 size-full object-cover"
        />
        <div
          className="absolute inset-0 -z-10"
          style={{ background: "var(--gradient-veil)" }}
          aria-hidden="true"
        />
        <div className="mx-auto flex max-w-7xl flex-col px-5 pb-20 pt-24 sm:pt-32 lg:px-8 lg:pb-28 lg:pt-40">
          <span className="w-fit rounded-full border border-border bg-background/60 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.28em] text-primary backdrop-blur">
            Tickets. Votes. Experiences.
          </span>
          <h1 className="mt-6 max-w-4xl text-4xl font-bold leading-[1.05] sm:text-6xl lg:text-7xl">
            Discover Events. Get Your Tickets.{" "}
            <span className="text-gradient">Make Your Vote Count.</span>
          </h1>
          <p className="mt-6 max-w-2xl text-base text-muted-foreground sm:text-lg">
            VOTIX brings event discovery, digital ticketing and audience voting into one
            platform. Find what's happening near you, buy tickets in seconds, and cast
            your vote in the polls and award categories that matter to you.
          </p>
          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Button asChild size="lg" className="shadow-glow">
              <Link to="/events">Explore Events</Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/create-event">Create an Event</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="border-y border-border bg-surface/40">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-5 py-10 lg:grid-cols-4 lg:px-8">
          {pillars.map(({ icon: Icon, title, body }) => (
            <div key={title}>
              <Icon className="size-6 text-primary" aria-hidden="true" />
              <h2 className="mt-3 text-base font-semibold">{title}</h2>
              <p className="mt-1.5 text-sm text-muted-foreground">{body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-5 py-16 lg:px-8 lg:py-24">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.28em] text-primary">
              Happening soon
            </p>
            <h2 className="mt-3 text-3xl font-bold sm:text-4xl">Featured events</h2>
          </div>
          <Button asChild variant="ghost">
            <Link to="/events">View all events</Link>
          </Button>
        </div>

        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {featuredEvents.map((event) => (
            <article
              key={event.title}
              className="group flex flex-col rounded-2xl border border-border bg-card p-6 shadow-card transition-transform duration-200 hover:-translate-y-1"
            >
              <span className="w-fit rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground">
                {event.category}
              </span>
              <h3 className="mt-4 text-xl font-semibold">{event.title}</h3>
              <p className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
                <CalendarDays className="size-4" aria-hidden="true" />
                {event.date}
              </p>
              <p className="mt-1.5 flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="size-4" aria-hidden="true" />
                {event.location}
              </p>
              <div className="mt-6 flex items-center justify-between border-t border-border pt-4">
                <span className="text-sm font-semibold text-primary">{event.price}</span>
                <Button asChild size="sm" variant="secondary">
                  <Link to="/events">Get tickets</Link>
                </Button>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="border-t border-border bg-surface/40">
        <div className="mx-auto flex max-w-7xl flex-col items-start gap-6 px-5 py-16 lg:flex-row lg:items-center lg:justify-between lg:px-8 lg:py-20">
          <div>
            <h2 className="text-3xl font-bold sm:text-4xl">
              Hosting something? Start selling today.
            </h2>
            <p className="mt-3 max-w-xl text-muted-foreground">
              Set up ticket tiers, open voting categories and track sales from one
              organiser dashboard.
            </p>
          </div>
          <Button asChild size="lg" className="shadow-glow">
            <Link to="/create-event">Create an Event</Link>
          </Button>
        </div>
      </section>
    </SiteLayout>
  );
}
