import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, SiteLayout } from "@/components/site/SiteLayout";

export const Route = createFileRoute("/how-it-works")({
  head: () => ({
    meta: [
      { title: "How It Works — VOTIX" },
      {
        name: "description",
        content:
          "See how VOTIX works for attendees and organisers: discover events, buy digital tickets, vote, and run your own event.",
      },
      { property: "og:title", content: "How It Works — VOTIX" },
      {
        property: "og:description",
        content: "How attendees and organisers use VOTIX for tickets and voting.",
      },
    ],
  }),
  component: HowItWorksPage,
});

const attendeeSteps = [
  {
    title: "Discover",
    body: "Browse events by city, category and date to find what's happening near you.",
  },
  {
    title: "Get your ticket",
    body: "Pick a ticket tier, pay securely and receive a QR ticket instantly.",
  },
  {
    title: "Vote",
    body: "Join open voting categories and watch results update in real time.",
  },
];

const organiserSteps = [
  {
    title: "Create the event",
    body: "Add your details, cover art, venue and schedule in a guided setup.",
  },
  {
    title: "Set tickets & categories",
    body: "Define ticket tiers, pricing and any nominee or poll categories.",
  },
  {
    title: "Publish & track",
    body: "Share your event link and follow ticket sales and votes as they come in.",
  },
];

function StepList({
  heading,
  steps,
}: {
  heading: string;
  steps: { title: string; body: string }[];
}) {
  return (
    <div>
      <h2 className="text-2xl font-bold">{heading}</h2>
      <ol className="mt-6 space-y-4">
        {steps.map((step, i) => (
          <li
            key={step.title}
            className="flex gap-4 rounded-2xl border border-border bg-card p-5 shadow-card"
          >
            <span className="grid size-9 shrink-0 place-items-center rounded-full bg-gradient-primary text-sm font-bold text-primary-foreground">
              {i + 1}
            </span>
            <div>
              <h3 className="text-base font-semibold">{step.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{step.body}</p>
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}

function HowItWorksPage() {
  return (
    <SiteLayout>
      <PageHeader
        eyebrow="Guide"
        title="How It Works"
        description="VOTIX connects attendees and organisers around one event page — tickets on one side, voting on the other."
      />
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-16 lg:grid-cols-2 lg:px-8 lg:py-20">
        <StepList heading="For attendees" steps={attendeeSteps} />
        <StepList heading="For organisers" steps={organiserSteps} />
      </div>
    </SiteLayout>
  );
}
