import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Mail, Phone, Send } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { PageHeader, SiteLayout } from "@/components/site/SiteLayout";
import { SUPPORT_EMAIL, SUPPORT_PHONE, submitContactMessage } from "@/lib/contact.functions";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact VOTIX Support — Tickets, Events & Voting Help" },
      {
        name: "description",
        content:
          "Reach the VOTIX support team about tickets, events or voting. Email Support@votixnigeria.com, call 09167566262 or send us a message.",
      },
      { property: "og:title", content: "Contact VOTIX Support" },
      {
        property: "og:description",
        content: "Get help with VOTIX tickets, events and voting — email, phone or message form.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const sendMessage = useServerFn(submitContactMessage);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [pending, setPending] = useState(false);
  const [sent, setSent] = useState(false);

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    setPending(true);
    try {
      const result = await sendMessage({ data: { name, email, subject, message } });
      if (!result.ok) {
        toast.error(result.error);
        return;
      }
      setSent(true);
      setName("");
      setEmail("");
      setSubject("");
      setMessage("");
      toast.success("Message sent — our support team will reply by email.");
    } catch {
      toast.error("Your message could not be sent. Please try again.");
    } finally {
      setPending(false);
    }
  }

  return (
    <SiteLayout>
      <PageHeader
        eyebrow="Support"
        title="Contact VOTIX"
        description="Questions about a ticket, an event or a vote? Our support team is here to help."
      />

      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-12 lg:grid-cols-[1fr_1.2fr] lg:px-8 lg:py-16">
        <aside className="space-y-4">
          <a
            href={`mailto:${SUPPORT_EMAIL}`}
            className="flex items-start gap-4 rounded-2xl border border-border bg-card p-5 shadow-card transition-colors hover:border-primary"
          >
            <Mail className="mt-0.5 size-5 text-primary" aria-hidden="true" />
            <span>
              <span className="block text-xs uppercase tracking-wider text-muted-foreground">
                Support email
              </span>
              <span className="mt-1 block font-medium break-all">{SUPPORT_EMAIL}</span>
            </span>
          </a>

          <a
            href={`tel:${SUPPORT_PHONE}`}
            className="flex items-start gap-4 rounded-2xl border border-border bg-card p-5 shadow-card transition-colors hover:border-primary"
          >
            <Phone className="mt-0.5 size-5 text-primary" aria-hidden="true" />
            <span>
              <span className="block text-xs uppercase tracking-wider text-muted-foreground">
                Phone
              </span>
              <span className="mt-1 block font-medium">{SUPPORT_PHONE}</span>
            </span>
          </a>

          <div className="rounded-2xl border border-border bg-card p-5 text-sm text-muted-foreground shadow-card">
            <p className="font-medium text-foreground">Support hours</p>
            <p className="mt-1">Monday to Saturday, 9am – 6pm (WAT).</p>
            <p className="mt-3">
              For ticket issues, include the payment reference from your confirmation so we can find
              your order quickly.
            </p>
          </div>
        </aside>

        <section
          aria-labelledby="contact-form-heading"
          className="rounded-2xl border border-border bg-card p-6 shadow-card lg:p-8"
        >
          <h2 id="contact-form-heading" className="text-xl font-semibold">
            Send us a message
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            We reply to {SUPPORT_EMAIL} enquiries within one business day.
          </p>

          {sent && (
            <p className="mt-4 rounded-xl border border-secondary/40 bg-secondary/10 p-4 text-sm">
              Thanks — your message has reached our support team.
            </p>
          )}

          <form className="mt-6 space-y-4" onSubmit={handleSubmit}>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="contact-name">Name</Label>
                <Input
                  id="contact-name"
                  required
                  minLength={2}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your full name"
                  autoComplete="name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="contact-email">Email</Label>
                <Input
                  id="contact-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  autoComplete="email"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="contact-subject">Subject</Label>
              <Input
                id="contact-subject"
                required
                minLength={2}
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="What is this about?"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="contact-message">Message</Label>
              <Textarea
                id="contact-message"
                required
                minLength={10}
                rows={6}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Tell us what you need help with"
              />
            </div>
            <Button type="submit" className="w-full shadow-glow sm:w-auto" disabled={pending}>
              <Send className="size-4" aria-hidden="true" />
              {pending ? "Sending…" : "Send message"}
            </Button>
          </form>
        </section>
      </div>
    </SiteLayout>
  );
}
