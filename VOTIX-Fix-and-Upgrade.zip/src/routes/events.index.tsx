import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { PageHeader, SiteLayout } from "@/components/site/SiteLayout";
import { EventCard } from "@/components/events/EventCard";
import { EVENT_CATEGORIES, mapEvent } from "@/data/events";
import { listPublicEvents } from "@/lib/events.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/events/")({
  head: () => ({
    meta: [
      { title: "Events — VOTIX" },
      {
        name: "description",
        content:
          "Browse upcoming concerts, conferences, award nights and festivals, and secure your digital tickets on VOTIX.",
      },
      { property: "og:title", content: "Events — VOTIX" },
      {
        property: "og:description",
        content: "Browse upcoming events and get digital tickets on VOTIX.",
      },
    ],
  }),
  loader: () => listPublicEvents(),
  component: EventsPage,
});

type Filter = "All" | (typeof EVENT_CATEGORIES)[number];
const filters: Filter[] = ["All", ...EVENT_CATEGORIES];

function EventsPage() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<Filter>("All");
  const { events } = Route.useLoaderData();
  const allEvents = useMemo(() => events.map(mapEvent), [events]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return allEvents.filter((event) => {
      const matchesCategory = category === "All" || event.category === category;
      const matchesQuery =
        q.length === 0 ||
        [event.title, event.venue, event.city, event.organizer, event.category]
          .join(" ")
          .toLowerCase()
          .includes(q);
      return matchesCategory && matchesQuery;
    });
  }, [allEvents, category, query]);

  return (
    <SiteLayout>
      <PageHeader
        eyebrow="Discover"
        title="Upcoming events"
        description="Concerts, conferences, award nights and festivals — search by name, venue or city, then grab your digital ticket."
      />

      <div className="mx-auto max-w-7xl px-5 py-10 lg:px-8 lg:py-14">
        <div className="flex flex-col gap-5">
          <div className="relative max-w-xl">
            <Search
              className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden="true"
            />
            <Input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search events, venues or cities"
              aria-label="Search events"
              className="h-12 pl-10"
            />
          </div>

          <div
            role="group"
            aria-label="Filter by category"
            className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-1 sm:mx-0 sm:flex-wrap sm:px-0"
          >
            {filters.map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => setCategory(item)}
                aria-pressed={category === item}
                className={cn(
                  "shrink-0 rounded-full border px-4 py-2 text-sm font-medium transition-colors",
                  category === item
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border text-muted-foreground hover:text-foreground",
                )}
              >
                {item}
              </button>
            ))}
          </div>
        </div>

        <p className="mt-8 text-sm text-muted-foreground">
          {visible.length} {visible.length === 1 ? "event" : "events"} found
        </p>

        {visible.length > 0 ? (
          <div className="mt-5 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {visible.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        ) : (
          <div className="mt-5 rounded-2xl border border-dashed border-border p-12 text-center">
            <p className="font-medium">No events match your search</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Try a different keyword or category.
            </p>
          </div>
        )}
      </div>
    </SiteLayout>
  );
}
