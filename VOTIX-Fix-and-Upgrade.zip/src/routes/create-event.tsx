import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { PageHeader, SiteLayout } from "@/components/site/SiteLayout";

export const Route = createFileRoute("/create-event")({
  head: () => ({
    meta: [
      { title: "Create an Event — VOTIX" },
      {
        name: "description",
        content:
          "Publish your event on VOTIX: sell digital tickets, open voting categories and track everything from one dashboard.",
      },
      { property: "og:title", content: "Create an Event — VOTIX" },
      {
        property: "og:description",
        content: "Sell digital tickets and run audience voting for your event.",
      },
    ],
  }),
  component: CreateEventPage,
});

function CreateEventPage() {
  return (
    <SiteLayout>
      <PageHeader
        eyebrow="Organisers"
        title="Create an Event"
        description="Create a live event, add ticket tiers and configure voting from the organiser dashboard."
      />
      <div className="mx-auto max-w-7xl px-5 py-16 lg:px-8">
        <p className="text-muted-foreground">
          The full event builder is available in the organiser dashboard. Your event, ticket tiers and voting configuration are saved to VOTIX when you publish.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Button asChild className="shadow-glow">
            <Link to="/organizer">Go to organiser dashboard</Link>
          </Button>
          <Button asChild variant="outline">
            <Link to="/signup">Create an account</Link>
          </Button>
        </div>
      </div>
    </SiteLayout>
  );
}
