import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { PageHeader, SiteLayout } from "@/components/site/SiteLayout";
import { VotingSection } from "@/components/events/VotingSection";
import { VotingBadge } from "@/components/events/VotingBadge";
import { listPublicEvents } from "@/lib/events.functions";
import { mapEvent, type EventRecord } from "@/data/events";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/voting")({
  head: () => ({
    meta: [
      { title: "Voting — VOTIX" },
      {
        name: "description",
        content:
          "Cast your vote in live event polls, nominee categories and award shows with transparent, real-time results.",
      },
      { property: "og:title", content: "Voting — VOTIX" },
      {
        property: "og:description",
        content: "Live event polls and award categories with transparent real-time tallies.",
      },
    ],
  }),
  loader: () => listPublicEvents(),
  component: VotingPage,
});

function VotingPage() {
  const { events, error } = Route.useLoaderData();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"all" | "open" | "closed">("all");

  const votingEvents = useMemo(() => {
    const all = events.map(mapEvent).filter((event) => event.voteCategories.length > 0);
    const term = query.trim().toLowerCase();
    return all.filter((event) => {
      const statusMatches = filter === "all" || event.votingStatus === filter;
      const textMatches =
        !term ||
        [event.title, event.category, event.organizer, event.venue, event.city]
          .join(" ")
          .toLowerCase()
          .includes(term);
      return statusMatches && textMatches;
    });
  }, [events, filter, query]);

  return (
    <SiteLayout>
      <PageHeader
        eyebrow="Participate"
        title="Voting"
        description="Choose an event, select your nominees and submit one vote per category. Results update from the live VOTIX database."
      />

      <div className="mx-auto max-w-7xl px-5 py-10 lg:px-8 lg:py-14">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <div className="relative max-w-xl flex-1">
            <Search
              className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
              aria-hidden="true"
            />
            <Input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search voting events"
              aria-label="Search voting events"
              className="h-12 pl-10"
            />
          </div>
          <div className="flex gap-2" role="group" aria-label="Voting status filter">
            {(["all", "open", "closed"] as const).map((value) => (
              <button
                key={value}
                type="button"
                aria-pressed={filter === value}
                onClick={() => setFilter(value)}
                className={cn(
                  "rounded-full border px-4 py-2 text-sm font-medium capitalize transition-colors",
                  filter === value
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border text-muted-foreground hover:text-foreground",
                )}
              >
                {value}
              </button>
            ))}
          </div>
        </div>

        {error && (
          <div className="mt-6 rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive">
            {error}
          </div>
        )}

        {votingEvents.length === 0 ? (
          <div className="mt-8 rounded-2xl border border-dashed border-border p-12 text-center">
            <p className="font-medium">No voting campaigns found</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Published events with voting categories will appear here automatically.
            </p>
            <Link to="/events" className="mt-5 inline-block text-sm font-medium text-primary hover:underline">
              Browse events
            </Link>
          </div>
        ) : (
          <div className="mt-8 space-y-10">
            {votingEvents.map((event) => (
              <VotingEventCard key={event.id} event={event} />
            ))}
          </div>
        )}
      </div>
    </SiteLayout>
  );
}

function VotingEventCard({ event }: { event: EventRecord }) {
  return (
    <article className="overflow-hidden rounded-2xl border border-border bg-card shadow-card">
      <div className="grid lg:grid-cols-[300px_1fr]">
        <div className="min-h-52 bg-muted lg:min-h-full">
          <img src={event.image} alt="" className="h-full w-full object-cover" />
        </div>
        <div className="p-5 sm:p-6">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">{event.category}</p>
              <h2 className="mt-2 text-2xl font-bold">{event.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">Organised by {event.organizer}</p>
            </div>
            <VotingBadge status={event.votingStatus} />
          </div>
          <div className="mt-6">
            <VotingSection event={event} />
          </div>
        </div>
      </div>
    </article>
  );
}
