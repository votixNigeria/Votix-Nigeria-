import { useEffect, useState } from "react";
import { createFileRoute, Link, useSearch } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SiteLayout } from "@/components/site/SiteLayout";
import { verifyCheckout } from "@/lib/checkout.functions";

export const Route = createFileRoute("/payment/callback")({
  ssr: false,
  validateSearch: (search: Record<string, unknown>) => ({
    reference: typeof search["reference"] === "string" ? search["reference"] : "",
  }),
  head: () => ({
    meta: [
      { title: "Payment confirmation — VOTIX" },
      { name: "description", content: "Confirming your VOTIX ticket purchase." },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "Payment confirmation — VOTIX" },
      { property: "og:description", content: "Confirming your VOTIX ticket purchase." },
    ],
  }),
  component: PaymentCallbackPage,
});

function PaymentCallbackPage() {
  const { reference } = useSearch({ from: "/payment/callback" });
  const verify = useServerFn(verifyCheckout);
  const [state, setState] = useState<"pending" | "success" | "error">("pending");
  const [error, setError] = useState("Payment could not be confirmed.");

  useEffect(() => {
    let cancelled = false;
    if (!reference) {
      setState("error");
      setError("Missing payment reference.");
      return;
    }
    verify({ data: { reference } })
      .then((result) => {
        if (cancelled) return;
        if (result.ok) setState("success");
        else {
          setError(result.error);
          setState("error");
        }
      })
      .catch(() => {
        if (!cancelled) setState("error");
      });
    return () => {
      cancelled = true;
    };
  }, [reference, verify]);

  return (
    <SiteLayout>
      <div className="mx-auto max-w-xl px-5 py-24 text-center">
        {state === "pending" && (
          <>
            <h1 className="text-2xl font-bold">Confirming your payment…</h1>
            <p className="mt-3 text-muted-foreground">This only takes a moment.</p>
          </>
        )}

        {state === "success" && (
          <>
            <CheckCircle2 className="mx-auto size-12 text-primary" aria-hidden="true" />
            <h1 className="mt-5 text-2xl font-bold">Payment confirmed</h1>
            <p className="mt-3 text-muted-foreground">
              Your digital tickets have been issued and are in your wallet.
            </p>
            <Button asChild className="mt-6 shadow-glow">
              <Link to="/my-tickets">View my tickets</Link>
            </Button>
          </>
        )}

        {state === "error" && (
          <>
            <XCircle className="mx-auto size-12 text-destructive" aria-hidden="true" />
            <h1 className="mt-5 text-2xl font-bold">Payment not completed</h1>
            <p className="mt-3 text-muted-foreground">{error}</p>
            <Button asChild variant="outline" className="mt-6">
              <Link to="/events">Back to events</Link>
            </Button>
          </>
        )}
      </div>
    </SiteLayout>
  );
}
