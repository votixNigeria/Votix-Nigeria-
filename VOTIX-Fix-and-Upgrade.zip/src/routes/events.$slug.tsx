import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { CalendarDays, Clock, MapPin, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SiteLayout } from "@/components/site/SiteLayout";
import { TicketSelector } from "@/components/events/TicketSelector";
import { VotingSection } from "@/components/events/VotingSection";
import { VotingBadge } from "@/components/events/VotingBadge";
import {
  formatEventDate,
  formatEventTime,
  mapEvent,
  type EventRecord,
} from "@/data/events";
import { getPublicEvent } from "@/lib/events.functions";

export const Route = createFileRoute("/events/$slug")({
  loader: async ({ params }) => {
    const { event } = await getPublicEvent({ data: { slug: params.slug } });
    if (!event) throw notFound();
    return { event: mapEvent(event) };
  },
  errorComponent: EventNotFound,
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Event not found — VOTIX" }, { name: "robots", content: "noindex" }],
      };
    }
    const { event } = loaderData;
    const description = `${event.title} at ${event.venue}, ${event.city} on ${formatEventDate(event.startsAt)}. Get digital tickets on VOTIX.`;
    return {
      meta: [
        { title: `${event.title} — VOTIX` },
        { name: "description", content: description },
        { property: "og:title", content: `${event.title} — VOTIX` },
        { property: "og:description", content: description },
      ],
    };
  },
  notFoundComponent: EventNotFound,
  component: EventDetailPage,
});

function EventNotFound() {
  return (
    <SiteLayout>
      <div className="mx-auto max-w-3xl px-5 py-24 text-center">
        <h1 className="text-3xl font-bold">Event not found</h1>
        <p className="mt-3 text-muted-foreground">
          This event may have been removed or the link is incorrect.
        </p>
        <Button asChild className="mt-6">
          <Link to="/events">Back to events</Link>
        </Button>
      </div>
    </SiteLayout>
  );
}

function MetaRow({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof CalendarDays;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-3">
      <Icon className="mt-0.5 size-5 shrink-0 text-primary" aria-hidden="true" />
      <div>
        <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
        <p className="text-sm font-medium">{value}</p>
      </div>
    </div>
  );
}

function EventDetailPage() {
  const { event } = Route.useLoaderData() as { event: EventRecord };

  return (
    <SiteLayout>
      <section className="relative isolate">
        <img
          src={event.image}
          alt={`${event.title} banner`}
          width={1280}
          height={800}
          className="absolute inset-0 -z-20 size-full object-cover"
        />
        <div
          className="absolute inset-0 -z-10"
          style={{ background: "var(--gradient-veil)" }}
          aria-hidden="true"
        />
        <div className="mx-auto max-w-7xl px-5 pb-12 pt-20 sm:pt-28 lg:px-8 lg:pb-16 lg:pt-36">
          <div className="flex flex-wrap items-center gap-3">
            <span className="rounded-full bg-background/70 px-3 py-1 text-xs font-medium backdrop-blur">
              {event.category}
            </span>
            <VotingBadge status={event.votingStatus} />
          </div>
          <h1 className="mt-5 max-w-3xl text-3xl font-bold sm:text-5xl">{event.title}</h1>
          <p className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
            <UserRound className="size-4" aria-hidden="true" />
            Organised by {event.organizer}
          </p>
        </div>
      </section>

      <div className="mx-auto grid max-w-7xl gap-8 px-5 py-12 lg:grid-cols-[1.6fr_1fr] lg:items-start lg:px-8 lg:py-16">
        <div className="space-y-8">
          <div className="grid gap-5 rounded-2xl border border-border bg-card p-5 shadow-card sm:grid-cols-3 sm:p-6">
            <MetaRow icon={CalendarDays} label="Date" value={formatEventDate(event.startsAt)} />
            <MetaRow
              icon={Clock}
              label="Time"
              value={`${formatEventTime(event.startsAt)} – ${formatEventTime(event.endsAt)}`}
            />
            <MetaRow
              icon={MapPin}
              label="Venue"
              value={`${event.venue}, ${event.city}`}
            />
          </div>

          <section aria-labelledby="about-heading">
            <h2 id="about-heading" className="text-xl font-semibold">
              About this event
            </h2>
            <div className="mt-4 space-y-4 text-muted-foreground">
              {event.description.map((paragraph) => (
                <p key={paragraph.slice(0, 32)}>{paragraph}</p>
              ))}
            </div>
          </section>

          {event.votingStatus !== "none" && event.voteCategories.length > 0 && (
            <VotingSection event={event} />
          )}
        </div>

        <div className="lg:sticky lg:top-24">
          <TicketSelector event={event} />
        </div>
      </div>
    </SiteLayout>
  );
}
