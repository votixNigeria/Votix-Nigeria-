import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { CalendarDays, MapPin, Ticket } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageHeader, SiteLayout } from "@/components/site/SiteLayout";
import { formatEventDate, formatEventTime } from "@/data/events";
import { listMyTickets } from "@/lib/tickets.functions";

export const Route = createFileRoute("/_authenticated/my-tickets")({
  head: () => ({
    meta: [
      { title: "My Tickets — VOTIX" },
      {
        name: "description",
        content: "View your purchased VOTIX digital tickets and jump back to each event.",
      },
      { property: "og:title", content: "My Tickets — VOTIX" },
      { property: "og:description", content: "Your VOTIX digital tickets in one place." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MyTicketsPage,
});

function MyTicketsPage() {
  const fetchTickets = useServerFn(listMyTickets);
  const { data, isLoading, error } = useQuery({
    queryKey: ["my-tickets"],
    queryFn: () => fetchTickets(),
  });

  const tickets = data?.tickets ?? [];

  return (
    <SiteLayout>
      <PageHeader
        eyebrow="Your wallet"
        title="My Tickets"
        description="Every digital ticket you've purchased on VOTIX, with a link back to the event."
      />

      <div className="mx-auto max-w-5xl px-5 py-12 lg:px-8 lg:py-16">
        {isLoading && <p className="text-muted-foreground">Loading your tickets…</p>}
        {error && <p className="text-destructive">Could not load your tickets.</p>}

        {!isLoading && !error && tickets.length === 0 && (
          <div className="rounded-2xl border border-dashed border-border p-12 text-center">
            <Ticket className="mx-auto size-8 text-muted-foreground" aria-hidden="true" />
            <p className="mt-4 font-medium">No tickets yet</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Once you buy a ticket it appears here instantly.
            </p>
            <Button asChild className="mt-6">
              <Link to="/events">Browse events</Link>
            </Button>
          </div>
        )}

        <div className="grid gap-5 sm:grid-cols-2">
          {tickets.map((ticket) => (
            <article
              key={ticket.id}
              className="flex flex-col rounded-2xl border border-border bg-card p-5 shadow-card"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="text-lg font-semibold">{ticket.eventTitle}</h2>
                  <p className="mt-1 text-sm text-primary">{ticket.tierName}</p>
                </div>
                <span className="rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground">
                  {ticket.checkedIn ? "Checked in" : "Valid"}
                </span>
              </div>

              <p className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
                <CalendarDays className="size-4" aria-hidden="true" />
                {formatEventDate(ticket.eventStartsAt)} · {formatEventTime(ticket.eventStartsAt)}
              </p>
              <p className="mt-1.5 flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="size-4" aria-hidden="true" />
                {ticket.eventVenue}
                {ticket.eventCity ? `, ${ticket.eventCity}` : ""}
              </p>

              <div className="mt-5 rounded-xl border border-dashed border-border bg-muted/30 p-4 text-center">
                <p className="text-xs uppercase tracking-wider text-muted-foreground">
                  Ticket code
                </p>
                <p className="mt-1 font-mono text-lg font-semibold">{ticket.ticketCode}</p>
              </div>

              <div className="mt-5 border-t border-border pt-4">
                <Button asChild size="sm" variant="secondary">
                  <Link to="/events/$slug" params={{ slug: ticket.eventSlug }}>
                    View event
                  </Link>
                </Button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </SiteLayout>
  );
}
