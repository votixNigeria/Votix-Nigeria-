import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  CalendarDays,
  Search,
  ShieldAlert,
  ShieldCheck,
  Ticket,
  Trash2,
  Users,
  Vote,
  Wallet,
  Mail,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PageHeader, SiteLayout } from "@/components/site/SiteLayout";
import { formatPrice } from "@/data/events";
import {
  listContactSubmissions,
  setContactHandled,
} from "@/lib/contact.functions";
import {
  adminOverview,
  deleteEventAdmin,
  listAllEventsAdmin,
  listAllTransactions,
  listAllUsersAdmin,
  listAdminWallets,
  adjustUserBalance,
  setUserBalance,
  setEventPublishedAdmin,
  setEventVotingAdmin,
} from "@/lib/admin.functions";

const STATUSES = ["all", "paid", "pending", "failed"] as const;
type StatusFilter = (typeof STATUSES)[number];

const TABS = ["overview", "transactions", "events", "users", "wallets", "messages"] as const;
type Tab = (typeof TABS)[number];

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Admin Dashboard — VOTIX" },
      {
        name: "description",
        content: "VOTIX administrator control panel: platform overview, transaction audit, event controls and user accounts.",
      },
      { property: "og:title", content: "Admin Dashboard — VOTIX" },
      { property: "og:description", content: "VOTIX administrator control panel." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

function statusClasses(status: string) {
  if (status === "paid") return "bg-secondary text-secondary-foreground";
  if (status === "failed") return "bg-destructive/15 text-destructive";
  return "bg-muted text-muted-foreground";
}

function StatCard({ label, value, icon: Icon }: { label: string; value: string; icon: typeof Wallet }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-card">
      <div className="flex items-center justify-between">
        <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
        <Icon className="size-4 text-muted-foreground" aria-hidden="true" />
      </div>
      <p className="mt-2 text-2xl font-bold">{value}</p>
    </div>
  );
}

function AdminPage() {
  const queryClient = useQueryClient();
  const fetchOverview = useServerFn(adminOverview);
  const fetchTransactions = useServerFn(listAllTransactions);
  const fetchEvents = useServerFn(listAllEventsAdmin);
  const fetchUsers = useServerFn(listAllUsersAdmin);
  const fetchMessages = useServerFn(listContactSubmissions);
  const fetchWallets = useServerFn(listAdminWallets);
  const adjustBalance = useServerFn(adjustUserBalance);
  const setBalance = useServerFn(setUserBalance);
  const handleMessage = useServerFn(setContactHandled);
  const publishEvent = useServerFn(setEventPublishedAdmin);
  const toggleVoting = useServerFn(setEventVotingAdmin);
  const removeEvent = useServerFn(deleteEventAdmin);

  const [tab, setTab] = useState<Tab>("overview");
  const [search, setSearch] = useState("");
  const [term, setTerm] = useState("");
  const [status, setStatus] = useState<StatusFilter>("all");
  const [walletUserId, setWalletUserId] = useState("");
  const [walletAmount, setWalletAmount] = useState("");
  const [walletDescription, setWalletDescription] = useState("");

  const overviewQuery = useQuery({
    queryKey: ["admin-overview"],
    queryFn: () => fetchOverview(),
  });
  const transactionsQuery = useQuery({
    queryKey: ["admin-transactions", term, status],
    queryFn: () => fetchTransactions({ data: { search: term, status } }),
    enabled: tab === "transactions" || tab === "overview",
  });
  const eventsQuery = useQuery({
    queryKey: ["admin-events"],
    queryFn: () => fetchEvents(),
    enabled: tab === "events",
  });
  const usersQuery = useQuery({
    queryKey: ["admin-users"],
    queryFn: () => fetchUsers(),
    enabled: tab === "users",
  });
  const walletsQuery = useQuery({
    queryKey: ["admin-wallets"],
    queryFn: () => fetchWallets(),
    enabled: tab === "wallets",
  });
  const messagesQuery = useQuery({
    queryKey: ["admin-messages"],
    queryFn: () => fetchMessages(),
    enabled: tab === "messages",
  });

  const eventMutation = useMutation({
    mutationFn: async (action: { kind: "publish"; id: string; value: boolean } | { kind: "voting"; id: string; value: boolean } | { kind: "delete"; id: string }) => {
      if (action.kind === "publish")
        return publishEvent({ data: { eventId: action.id, publish: action.value } });
      if (action.kind === "voting")
        return toggleVoting({ data: { eventId: action.id, open: action.value } });
      return removeEvent({ data: { eventId: action.id } });
    },
    onSuccess: (result) => {
      if (!result.ok) {
        toast.error(result.error);
        return;
      }
      toast.success("Event updated.");
      queryClient.invalidateQueries({ queryKey: ["admin-events"] });
      queryClient.invalidateQueries({ queryKey: ["admin-overview"] });
    },
    onError: () => toast.error("Something went wrong."),
  });

  const denied =
    overviewQuery.data?.ok === false ||
    transactionsQuery.data?.ok === false ||
    eventsQuery.data?.ok === false ||
    usersQuery.data?.ok === false ||
    messagesQuery.data?.ok === false;

  const overview = overviewQuery.data?.ok ? overviewQuery.data.overview : null;
  const transactions = transactionsQuery.data?.ok ? transactionsQuery.data.transactions : [];
  const totals = transactionsQuery.data?.ok ? transactionsQuery.data.totals : null;
  const events = eventsQuery.data?.ok ? eventsQuery.data.events : [];
  const users = usersQuery.data?.ok ? usersQuery.data.users : [];
  const messages = messagesQuery.data?.ok ? messagesQuery.data.submissions : [];
  const wallets = walletsQuery.data?.ok ? walletsQuery.data.wallets : [];

  return (
    <SiteLayout>
      <PageHeader
        eyebrow="Admin"
        title="Admin dashboard"
        description="Full control of VOTIX: platform numbers, every transaction, every event and every account."
      />

      <div className="mx-auto max-w-7xl px-5 py-12 lg:px-8 lg:py-16">
        {denied && (
          <div className="rounded-2xl border border-border bg-card p-10 text-center shadow-card">
            <ShieldAlert className="mx-auto size-8 text-destructive" aria-hidden="true" />
            <p className="mt-4 font-medium">This account is not an administrator</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Sign in with the admin account to open the dashboard.
            </p>
            <Button asChild className="mt-6" variant="outline">
              <Link to="/admin-login">Go to admin sign-in</Link>
            </Button>
          </div>
        )}

        {!denied && (
          <>
            <div className="flex gap-2 overflow-x-auto" role="tablist" aria-label="Admin sections">
              {TABS.map((value) => (
                <Button
                  key={value}
                  type="button"
                  size="sm"
                  variant={tab === value ? "default" : "outline"}
                  onClick={() => setTab(value)}
                  className="capitalize"
                  role="tab"
                  aria-selected={tab === value}
                >
                  {value}
                </Button>
              ))}
            </div>

            {tab === "overview" && (
              <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <StatCard label="Gross paid" value={overview ? formatPrice(overview.grossPaid) : "—"} icon={Wallet} />
                <StatCard label="Orders" value={overview ? String(overview.orders) : "—"} icon={Ticket} />
                <StatCard label="Tickets issued" value={overview ? String(overview.tickets) : "—"} icon={Ticket} />
                <StatCard label="Votes cast" value={overview ? String(overview.votes) : "—"} icon={Vote} />
                <StatCard label="Events" value={overview ? `${overview.publishedEvents} live / ${overview.events} total` : "—"} icon={CalendarDays} />
                <StatCard label="Registered users" value={overview ? String(overview.users) : "—"} icon={Users} />
                <StatCard label="Pending / failed orders" value={totals ? `${totals.pendingCount} / ${totals.failedCount}` : "—"} icon={ShieldCheck} />
              </div>
            )}

            {tab === "transactions" && (
              <>
                <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  <StatCard label="Transactions" value={totals ? String(totals.count) : "—"} icon={Ticket} />
                  <StatCard label="Gross paid" value={totals ? formatPrice(totals.grossPaid) : "—"} icon={Wallet} />
                  <StatCard label="Tickets issued" value={totals ? String(totals.ticketsIssued) : "—"} icon={Ticket} />
                  <StatCard label="Pending / failed" value={totals ? `${totals.pendingCount} / ${totals.failedCount}` : "—"} icon={ShieldAlert} />
                </div>

                <form
                  className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center"
                  onSubmit={(e) => {
                    e.preventDefault();
                    setTerm(search);
                  }}
                >
                  <div className="relative flex-1">
                    <Search
                      className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground"
                      aria-hidden="true"
                    />
                    <Input
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      placeholder="Search buyer, event or payment reference"
                      className="pl-9"
                      aria-label="Search transactions"
                    />
                  </div>
                  <div className="flex gap-2 overflow-x-auto">
                    {STATUSES.map((value) => (
                      <Button
                        key={value}
                        type="button"
                        size="sm"
                        variant={status === value ? "default" : "outline"}
                        onClick={() => setStatus(value)}
                        className="capitalize"
                      >
                        {value}
                      </Button>
                    ))}
                  </div>
                  <Button type="submit" size="sm" variant="secondary">
                    Search
                  </Button>
                </form>

                {transactionsQuery.isLoading && (
                  <p className="mt-8 text-muted-foreground">Loading transactions…</p>
                )}

                {!transactionsQuery.isLoading && transactions.length === 0 && (
                  <div className="mt-8 rounded-2xl border border-dashed border-border p-12 text-center">
                    <ShieldCheck className="mx-auto size-8 text-muted-foreground" aria-hidden="true" />
                    <p className="mt-4 font-medium">No transactions match this view</p>
                  </div>
                )}

                {transactions.length > 0 && (
                  <div className="mt-8 overflow-x-auto rounded-2xl border border-border bg-card shadow-card">
                    <table className="w-full min-w-[900px] text-left text-sm">
                      <thead className="border-b border-border text-xs uppercase tracking-wider text-muted-foreground">
                        <tr>
                          <th className="px-4 py-3">Date</th>
                          <th className="px-4 py-3">Buyer</th>
                          <th className="px-4 py-3">Event</th>
                          <th className="px-4 py-3">Ticket type</th>
                          <th className="px-4 py-3">Qty</th>
                          <th className="px-4 py-3">Amount</th>
                          <th className="px-4 py-3">Status</th>
                          <th className="px-4 py-3">Reference</th>
                        </tr>
                      </thead>
                      <tbody>
                        {transactions.map((t) => (
                          <tr key={t.id} className="border-b border-border/60 last:border-0">
                            <td className="whitespace-nowrap px-4 py-3 text-muted-foreground">
                              {new Date(t.createdAt).toLocaleString()}
                            </td>
                            <td className="px-4 py-3">
                              <span className="block font-medium">{t.buyerName || "—"}</span>
                              <span className="text-xs text-muted-foreground">{t.buyerEmail}</span>
                            </td>
                            <td className="px-4 py-3">
                              {t.eventSlug ? (
                                <Link
                                  to="/events/$slug"
                                  params={{ slug: t.eventSlug }}
                                  className="text-primary hover:underline"
                                >
                                  {t.eventTitle}
                                </Link>
                              ) : (
                                t.eventTitle
                              )}
                            </td>
                            <td className="px-4 py-3 text-muted-foreground">{t.tierName}</td>
                            <td className="px-4 py-3">{t.quantity}</td>
                            <td className="px-4 py-3 font-semibold">{formatPrice(t.total)}</td>
                            <td className="px-4 py-3">
                              <span
                                className={`rounded-full px-2.5 py-1 text-xs font-medium capitalize ${statusClasses(t.status)}`}
                              >
                                {t.status}
                              </span>
                              <span className="mt-1 block text-xs text-muted-foreground">
                                {t.ticketsIssued} ticket{t.ticketsIssued === 1 ? "" : "s"}
                              </span>
                            </td>
                            <td className="px-4 py-3 font-mono text-xs text-muted-foreground">
                              {t.reference ?? "—"}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}

            {tab === "events" && (
              <>
                {eventsQuery.isLoading && <p className="mt-8 text-muted-foreground">Loading events…</p>}
                {!eventsQuery.isLoading && events.length === 0 && (
                  <div className="mt-8 rounded-2xl border border-dashed border-border p-12 text-center">
                    <CalendarDays className="mx-auto size-8 text-muted-foreground" aria-hidden="true" />
                    <p className="mt-4 font-medium">No events yet</p>
                  </div>
                )}
                {events.length > 0 && (
                  <div className="mt-8 overflow-x-auto rounded-2xl border border-border bg-card shadow-card">
                    <table className="w-full min-w-[900px] text-left text-sm">
                      <thead className="border-b border-border text-xs uppercase tracking-wider text-muted-foreground">
                        <tr>
                          <th className="px-4 py-3">Event</th>
                          <th className="px-4 py-3">Organizer</th>
                          <th className="px-4 py-3">Date</th>
                          <th className="px-4 py-3">Sales</th>
                          <th className="px-4 py-3">Status</th>
                          <th className="px-4 py-3">Voting</th>
                          <th className="px-4 py-3">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {events.map((ev) => (
                          <tr key={ev.id} className="border-b border-border/60 last:border-0">
                            <td className="px-4 py-3">
                              <Link
                                to="/events/$slug"
                                params={{ slug: ev.slug }}
                                className="font-medium text-primary hover:underline"
                              >
                                {ev.title}
                              </Link>
                              <span className="block text-xs capitalize text-muted-foreground">
                                {ev.category} · {ev.venue}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-muted-foreground">{ev.organizerName || "—"}</td>
                            <td className="whitespace-nowrap px-4 py-3 text-muted-foreground">
                              {new Date(ev.startsAt).toLocaleDateString()}
                            </td>
                            <td className="px-4 py-3">
                              {ev.orderCount} order{ev.orderCount === 1 ? "" : "s"} · {ev.ticketCount} ticket
                              {ev.ticketCount === 1 ? "" : "s"}
                            </td>
                            <td className="px-4 py-3">
                              <span
                                className={`rounded-full px-2.5 py-1 text-xs font-medium ${
                                  ev.isPublished
                                    ? "bg-secondary text-secondary-foreground"
                                    : "bg-muted text-muted-foreground"
                                }`}
                              >
                                {ev.isPublished ? "Published" : "Draft"}
                              </span>
                            </td>
                            <td className="px-4 py-3">
                              <span
                                className={`rounded-full px-2.5 py-1 text-xs font-medium ${
                                  ev.votingOpen
                                    ? "bg-secondary text-secondary-foreground"
                                    : "bg-muted text-muted-foreground"
                                }`}
                              >
                                {ev.votingOpen ? "Open" : "Closed"}
                              </span>
                            </td>
                            <td className="px-4 py-3">
                              <div className="flex flex-wrap gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  disabled={eventMutation.isPending}
                                  onClick={() =>
                                    eventMutation.mutate({ kind: "publish", id: ev.id, value: !ev.isPublished })
                                  }
                                >
                                  {ev.isPublished ? "Unpublish" : "Publish"}
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  disabled={eventMutation.isPending}
                                  onClick={() =>
                                    eventMutation.mutate({ kind: "voting", id: ev.id, value: !ev.votingOpen })
                                  }
                                >
                                  {ev.votingOpen ? "Close voting" : "Open voting"}
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  disabled={eventMutation.isPending}
                                  onClick={() => {
                                    if (window.confirm(`Delete "${ev.title}" and all its data? This cannot be undone.`))
                                      eventMutation.mutate({ kind: "delete", id: ev.id });
                                  }}
                                >
                                  <Trash2 className="size-3.5" aria-hidden="true" />
                                  Delete
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}

            {tab === "wallets" && (
              <section className="mt-8 space-y-6">
                <div>
                  <h2 className="text-xl font-semibold">Wallet control</h2>
                  <p className="mt-1 text-sm text-muted-foreground">Set an exact available balance with an auditable admin transaction.</p>
                </div>
                <form
                  className="grid gap-3 rounded-2xl border border-border bg-card p-5 shadow-card md:grid-cols-[1fr_160px_1.5fr_auto]"
                  onSubmit={async (e) => {
                    e.preventDefault();
                    const amount = Number(walletAmount);
                    if (!walletUserId || !Number.isFinite(amount) || amount < 0 || !walletDescription.trim()) {
                      toast.error("Enter a user, non-negative balance and reason.");
                      return;
                    }
                    const result = await setBalance({ data: { userId: walletUserId, amount, description: walletDescription.trim() } });
                    if (!result.ok) { toast.error(result.error); return; }
                    toast.success("Balance updated.");
                    setWalletAmount(""); setWalletDescription("");
                    void queryClient.invalidateQueries({ queryKey: ["admin-wallets"] });
                  }}
                >
                  <select value={walletUserId} onChange={(e) => setWalletUserId(e.target.value)} className="h-10 rounded-md border border-input bg-background px-3 text-sm" aria-label="Wallet user">
                    <option value="">Select user</option>
                    {wallets.map((w) => <option key={w.userId} value={w.userId}>{w.fullName || w.userId.slice(0, 8)}</option>)}
                  </select>
                  <Input type="number" min="0" step="0.01" value={walletAmount} onChange={(e) => setWalletAmount(e.target.value)} placeholder="Exact balance" aria-label="Exact balance" />
                  <Input value={walletDescription} onChange={(e) => setWalletDescription(e.target.value)} placeholder="Reason / audit note" aria-label="Adjustment reason" />
                  <Button type="submit">Set balance</Button>
                </form>
                {walletsQuery.isLoading && <p className="text-muted-foreground">Loading wallets…</p>}
                <div className="overflow-x-auto rounded-2xl border border-border bg-card shadow-card">
                  <table className="w-full text-sm">
                    <thead><tr className="border-b border-border text-left text-muted-foreground"><th className="p-4">User</th><th className="p-4">Available</th><th className="p-4">Pending</th><th className="p-4">Updated</th></tr></thead>
                    <tbody>{wallets.map((w) => <tr key={w.userId} className="border-b border-border last:border-0"><td className="p-4 font-medium">{w.fullName || w.userId}</td><td className="p-4">{formatPrice(w.availableBalance)}</td><td className="p-4">{formatPrice(w.pendingBalance)}</td><td className="p-4 text-muted-foreground">{new Date(w.updatedAt).toLocaleString("en-NG")}</td></tr>)}</tbody>
                  </table>
                  {!walletsQuery.isLoading && wallets.length === 0 && <p className="p-10 text-center text-muted-foreground">No wallets yet. A wallet is created when the first admin adjustment is made.</p>}
                </div>
              </section>
            )}

            {tab === "messages" && (
              <>
                {messagesQuery.isLoading && <p className="mt-8 text-muted-foreground">Loading messages…</p>}
                {!messagesQuery.isLoading && messages.length === 0 && (
                  <div className="mt-8 rounded-2xl border border-dashed border-border p-12 text-center">
                    <Mail className="mx-auto size-8 text-muted-foreground" aria-hidden="true" />
                    <p className="mt-4 font-medium">No contact messages</p>
                    <p className="mt-1 text-sm text-muted-foreground">New messages from the public contact form will appear here.</p>
                  </div>
                )}
                {messages.length > 0 && (
                  <div className="mt-8 space-y-4">
                    {messages.map((message) => (
                      <article key={message.id} className="rounded-2xl border border-border bg-card p-5 shadow-card">
                        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                          <div>
                            <div className="flex flex-wrap items-center gap-2">
                              <h2 className="font-semibold">{message.subject}</h2>
                              <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${message.handled ? "bg-secondary text-secondary-foreground" : "bg-primary/10 text-primary"}`}>
                                {message.handled ? "Handled" : "Open"}
                              </span>
                            </div>
                            <p className="mt-2 text-sm text-muted-foreground">
                              {message.name} · {message.email} · {new Date(message.createdAt).toLocaleString()}
                            </p>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={messagesQuery.isFetching}
                            onClick={async () => {
                              const result = await handleMessage({ data: { id: message.id, handled: !message.handled } });
                              if (!result.ok) {
                                toast.error(result.error);
                                return;
                              }
                              toast.success(message.handled ? "Message reopened." : "Message marked handled.");
                              void queryClient.invalidateQueries({ queryKey: ["admin-messages"] });
                            }}
                          >
                            {message.handled ? "Reopen" : "Mark handled"}
                          </Button>
                        </div>
                        <p className="mt-4 whitespace-pre-wrap text-sm leading-6 text-muted-foreground">{message.message}</p>
                      </article>
                    ))}
                  </div>
                )}
              </>
            )}

            {tab === "users" && (
              <>
                {usersQuery.isLoading && <p className="mt-8 text-muted-foreground">Loading users…</p>}
                {!usersQuery.isLoading && users.length === 0 && (
                  <div className="mt-8 rounded-2xl border border-dashed border-border p-12 text-center">
                    <Users className="mx-auto size-8 text-muted-foreground" aria-hidden="true" />
                    <p className="mt-4 font-medium">No accounts yet</p>
                  </div>
                )}
                {users.length > 0 && (
                  <div className="mt-8 overflow-x-auto rounded-2xl border border-border bg-card shadow-card">
                    <table className="w-full min-w-[700px] text-left text-sm">
                      <thead className="border-b border-border text-xs uppercase tracking-wider text-muted-foreground">
                        <tr>
                          <th className="px-4 py-3">Name</th>
                          <th className="px-4 py-3">Roles</th>
                          <th className="px-4 py-3">Joined</th>
                          <th className="px-4 py-3">Paid orders</th>
                          <th className="px-4 py-3">Total spent</th>
                        </tr>
                      </thead>
                      <tbody>
                        {users.map((u) => (
                          <tr key={u.id} className="border-b border-border/60 last:border-0">
                            <td className="px-4 py-3 font-medium">{u.fullName || "—"}</td>
                            <td className="px-4 py-3">
                              <div className="flex flex-wrap gap-1.5">
                                {u.roles.length === 0 && (
                                  <span className="text-xs text-muted-foreground">—</span>
                                )}
                                {u.roles.map((role) => (
                                  <span
                                    key={role}
                                    className={`rounded-full px-2.5 py-0.5 text-xs font-medium capitalize ${
                                      role === "admin"
                                        ? "bg-primary text-primary-foreground"
                                        : "bg-muted text-muted-foreground"
                                    }`}
                                  >
                                    {role}
                                  </span>
                                ))}
                              </div>
                            </td>
                            <td className="whitespace-nowrap px-4 py-3 text-muted-foreground">
                              {new Date(u.createdAt).toLocaleDateString()}
                            </td>
                            <td className="px-4 py-3">{u.orderCount}</td>
                            <td className="px-4 py-3 font-semibold">{formatPrice(u.totalSpent)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            )}
          </>
        )}
      </div>
    </SiteLayout>
  );
}
