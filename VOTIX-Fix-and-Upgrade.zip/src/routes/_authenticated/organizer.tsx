import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { PageHeader, SiteLayout } from "@/components/site/SiteLayout";
import {
  EVENT_CATEGORIES,
  formatEventDate,
  formatPrice,
  mapEvent,
  slugify,
} from "@/data/events";
import {
  createEvent,
  listMyEvents,
  setEventPublished,
  setTierAvailability,
  updateEventVoting,
} from "@/lib/organizer.functions";

export const Route = createFileRoute("/_authenticated/organizer")({
  head: () => ({
    meta: [
      { title: "Organiser Dashboard — VOTIX" },
      {
        name: "description",
        content:
          "Create events, set ticket tiers and manage voting categories from your VOTIX organiser dashboard.",
      },
      { property: "og:title", content: "Organiser Dashboard — VOTIX" },
      {
        property: "og:description",
        content: "Create events, price tickets and run voting on VOTIX.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: OrganizerPage,
});

interface TierDraft {
  name: string;
  description: string;
  price: string;
}

interface CategoryDraft {
  name: string;
  nominees: { name: string; subtitle: string }[];
}

function OrganizerPage() {
  const queryClient = useQueryClient();
  const fetchEvents = useServerFn(listMyEvents);
  const create = useServerFn(createEvent);
  const updateVoting = useServerFn(updateEventVoting);
  const publishEvent = useServerFn(setEventPublished);
  const toggleTier = useServerFn(setTierAvailability);

  const { data, isLoading } = useQuery({
    queryKey: ["organizer-events"],
    queryFn: () => fetchEvents(),
  });

  const events = (data?.events ?? []).map(mapEvent);
  const publishedById = new Map(
    (data?.events ?? []).map((row) => [row.id, row.published !== false] as const),
  );

  const [message, setMessage] = useState<string | null>(null);
  const [form, setForm] = useState({
    title: "",
    category: "Concert",
    organizerName: "",
    imageUrl: "",
    startsAt: "",
    endsAt: "",
    venue: "",
    city: "",
    description: "",
    votingStatus: "none" as "none" | "open" | "closed",
    votingClosesAt: "",
  });
  const [tiers, setTiers] = useState<TierDraft[]>([
    { name: "Regular", description: "General admission.", price: "5000" },
  ]);
  const [categories, setCategories] = useState<CategoryDraft[]>([]);

  const createMutation = useMutation({
    mutationFn: async () =>
      create({
        data: {
          title: form.title,
          slug: slugify(form.title),
          category: form.category,
          organizerName: form.organizerName || "VOTIX organiser",
          imageUrl: form.imageUrl || "",
          startsAt: new Date(form.startsAt).toISOString(),
          endsAt: form.endsAt ? new Date(form.endsAt).toISOString() : "",
          venue: form.venue,
          city: form.city,
          currency: "₦",
          description: form.description,
          votingStatus: form.votingStatus,
          votingClosesAt: form.votingClosesAt
            ? new Date(form.votingClosesAt).toISOString()
            : "",
          published: true,
          tiers: tiers.map((tier) => ({
            name: tier.name,
            description: tier.description,
            price: Number(tier.price) || 0,
          })),
          voteCategories: categories,
        },
      }),
    onSuccess: () => {
      setMessage("Event published.");
      setForm({
        title: "",
        category: "Concert",
        organizerName: form.organizerName,
        imageUrl: "",
        startsAt: "",
        endsAt: "",
        venue: "",
        city: "",
        description: "",
        votingStatus: "none",
        votingClosesAt: "",
      });
      setTiers([{ name: "Regular", description: "General admission.", price: "5000" }]);
      setCategories([]);
      void queryClient.invalidateQueries({ queryKey: ["organizer-events"] });
    },
    onError: (error: Error) => setMessage(error.message || "Could not create the event."),
  });

  const mutateAndRefresh = async (fn: () => Promise<unknown>) => {
    await fn();
    void queryClient.invalidateQueries({ queryKey: ["organizer-events"] });
  };

  return (
    <SiteLayout>
      <PageHeader
        eyebrow="Organisers"
        title="Organiser dashboard"
        description="Create events, set ticket tiers and open or close voting for your audience."
      />

      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-12 lg:grid-cols-[1.1fr_1fr] lg:items-start lg:px-8 lg:py-16">
        <section
          aria-labelledby="create-heading"
          className="rounded-2xl border border-border bg-card p-5 shadow-card sm:p-6"
        >
          <h2 id="create-heading" className="text-xl font-semibold">
            Create an event
          </h2>

          <form
            className="mt-6 space-y-5"
            onSubmit={(e) => {
              e.preventDefault();
              setMessage(null);
              createMutation.mutate();
            }}
          >
            <div className="space-y-2">
              <Label htmlFor="title">Event title</Label>
              <Input
                id="title"
                required
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <select
                  id="category"
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                >
                  {EVENT_CATEGORIES.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="organizerName">Organiser name</Label>
                <Input
                  id="organizerName"
                  value={form.organizerName}
                  onChange={(e) => setForm({ ...form, organizerName: e.target.value })}
                />
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="startsAt">Starts</Label>
                <Input
                  id="startsAt"
                  type="datetime-local"
                  required
                  value={form.startsAt}
                  onChange={(e) => setForm({ ...form, startsAt: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="endsAt">Ends</Label>
                <Input
                  id="endsAt"
                  type="datetime-local"
                  value={form.endsAt}
                  onChange={(e) => setForm({ ...form, endsAt: e.target.value })}
                />
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="venue">Venue</Label>
                <Input
                  id="venue"
                  required
                  value={form.venue}
                  onChange={(e) => setForm({ ...form, venue: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="city">City</Label>
                <Input
                  id="city"
                  required
                  value={form.city}
                  onChange={(e) => setForm({ ...form, city: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="imageUrl">Banner image URL</Label>
              <Input
                id="imageUrl"
                type="url"
                placeholder="https://…"
                value={form.imageUrl}
                onChange={(e) => setForm({ ...form, imageUrl: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                rows={5}
                placeholder="One paragraph per line."
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
            </div>

            <Separator />

            <div>
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Ticket tiers</h3>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() =>
                    setTiers([...tiers, { name: "", description: "", price: "0" }])
                  }
                >
                  <Plus className="size-4" /> Add tier
                </Button>
              </div>

              <div className="mt-4 space-y-4">
                {tiers.map((tier, index) => (
                  <div
                    key={index}
                    className="grid gap-3 rounded-xl border border-border p-4 sm:grid-cols-[1fr_1fr_auto]"
                  >
                    <Input
                      required
                      placeholder="Tier name"
                      value={tier.name}
                      onChange={(e) => {
                        const next = [...tiers];
                        next[index] = { ...tier, name: e.target.value };
                        setTiers(next);
                      }}
                    />
                    <Input
                      required
                      type="number"
                      min="0"
                      placeholder="Price"
                      value={tier.price}
                      onChange={(e) => {
                        const next = [...tiers];
                        next[index] = { ...tier, price: e.target.value };
                        setTiers(next);
                      }}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      aria-label="Remove tier"
                      disabled={tiers.length === 1}
                      onClick={() => setTiers(tiers.filter((_, i) => i !== index))}
                    >
                      <Trash2 className="size-4" />
                    </Button>
                    <Input
                      className="sm:col-span-3"
                      placeholder="Tier description"
                      value={tier.description}
                      onChange={(e) => {
                        const next = [...tiers];
                        next[index] = { ...tier, description: e.target.value };
                        setTiers(next);
                      }}
                    />
                  </div>
                ))}
              </div>
            </div>

            <Separator />

            <div>
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Voting</h3>
                <select
                  aria-label="Voting status"
                  value={form.votingStatus}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      votingStatus: e.target.value as "none" | "open" | "closed",
                    })
                  }
                  className="h-10 rounded-md border border-input bg-background px-3 text-sm"
                >
                  <option value="none">No voting</option>
                  <option value="open">Voting open</option>
                  <option value="closed">Voting closed</option>
                </select>
              </div>

              {form.votingStatus !== "none" && (
                <div className="mt-4 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="votingClosesAt">Voting closes</Label>
                    <Input
                      id="votingClosesAt"
                      type="datetime-local"
                      value={form.votingClosesAt}
                      onChange={(e) => setForm({ ...form, votingClosesAt: e.target.value })}
                    />
                  </div>

                  {categories.map((category, cIndex) => (
                    <div key={cIndex} className="space-y-3 rounded-xl border border-border p-4">
                      <div className="flex gap-3">
                        <Input
                          placeholder="Category name"
                          value={category.name}
                          onChange={(e) => {
                            const next = [...categories];
                            next[cIndex] = { ...category, name: e.target.value };
                            setCategories(next);
                          }}
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          aria-label="Remove category"
                          onClick={() =>
                            setCategories(categories.filter((_, i) => i !== cIndex))
                          }
                        >
                          <Trash2 className="size-4" />
                        </Button>
                      </div>

                      {category.nominees.map((nominee, nIndex) => (
                        <div key={nIndex} className="grid gap-3 sm:grid-cols-2">
                          <Input
                            placeholder="Nominee name"
                            value={nominee.name}
                            onChange={(e) => {
                              const next = [...categories];
                              const nominees = [...category.nominees];
                              nominees[nIndex] = { ...nominee, name: e.target.value };
                              next[cIndex] = { ...category, nominees };
                              setCategories(next);
                            }}
                          />
                          <Input
                            placeholder="Nominee subtitle"
                            value={nominee.subtitle}
                            onChange={(e) => {
                              const next = [...categories];
                              const nominees = [...category.nominees];
                              nominees[nIndex] = { ...nominee, subtitle: e.target.value };
                              next[cIndex] = { ...category, nominees };
                              setCategories(next);
                            }}
                          />
                        </div>
                      ))}

                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          const next = [...categories];
                          next[cIndex] = {
                            ...category,
                            nominees: [...category.nominees, { name: "", subtitle: "" }],
                          };
                          setCategories(next);
                        }}
                      >
                        <Plus className="size-4" /> Add nominee
                      </Button>
                    </div>
                  ))}

                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    onClick={() => setCategories([...categories, { name: "", nominees: [] }])}
                  >
                    <Plus className="size-4" /> Add voting category
                  </Button>
                </div>
              )}
            </div>

            {message && <p className="text-sm text-primary">{message}</p>}

            <Button
              type="submit"
              size="lg"
              className="w-full shadow-glow"
              disabled={createMutation.isPending}
            >
              {createMutation.isPending ? "Publishing…" : "Publish event"}
            </Button>
          </form>
        </section>

        <section aria-labelledby="my-events-heading" className="space-y-5">
          <h2 id="my-events-heading" className="text-xl font-semibold">
            Your events
          </h2>

          {isLoading && <p className="text-muted-foreground">Loading your events…</p>}
          {!isLoading && events.length === 0 && (
            <p className="rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
              You haven't created an event yet.
            </p>
          )}

          {events.map((event) => (
            <article
              key={event.id}
              className="rounded-2xl border border-border bg-card p-5 shadow-card"
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h3 className="text-lg font-semibold">{event.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {formatEventDate(event.startsAt)} · {event.venue}, {event.city}
                  </p>
                </div>
                <Button asChild size="sm" variant="secondary">
                  <Link to="/events/$slug" params={{ slug: event.slug }}>
                    View
                  </Link>
                </Button>
              </div>

              <ul className="mt-4 space-y-2">
                {event.ticketTiers.map((tier) => (
                  <li
                    key={tier.id}
                    className="flex items-center justify-between rounded-lg border border-border px-3 py-2 text-sm"
                  >
                    <span>
                      {tier.name} · {formatPrice(tier.price, event.currency)}
                    </span>
                    <Button
                      type="button"
                      size="sm"
                      variant="ghost"
                      onClick={() =>
                        void mutateAndRefresh(() =>
                          toggleTier({ data: { tierId: tier.id, available: !tier.available } }),
                        )
                      }
                    >
                      {tier.available ? "Mark sold out" : "Re-open sales"}
                    </Button>
                  </li>
                ))}
              </ul>

              <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-border pt-4">
                <span className="text-sm text-muted-foreground">
                  Voting: {event.votingStatus}
                </span>
                <div className="ml-auto flex flex-wrap gap-2">
                  {(["none", "open", "closed"] as const).map((status) => (
                    <Button
                      key={status}
                      type="button"
                      size="sm"
                      variant={event.votingStatus === status ? "default" : "outline"}
                      onClick={() =>
                        void mutateAndRefresh(() =>
                          updateVoting({
                            data: { eventId: event.id, votingStatus: status },
                          }),
                        )
                      }
                    >
                      {status}
                    </Button>
                  ))}
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() =>
                      void mutateAndRefresh(() =>
                        publishEvent({
                          data: {
                            eventId: event.id,
                            published: !(publishedById.get(event.id) ?? true),
                          },
                        }),
                      )
                    }
                  >
                    {publishedById.get(event.id) ?? true ? "Unpublish" : "Publish"}
                  </Button>
                </div>
              </div>
            </article>
          ))}
        </section>
      </div>
    </SiteLayout>
  );
}
