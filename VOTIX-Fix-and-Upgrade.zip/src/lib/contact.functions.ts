import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";

export const SUPPORT_EMAIL = "Support@votixnigeria.com";
export const SUPPORT_PHONE = "09167566262";

const contactSchema = z.object({
  name: z.string().trim().min(2).max(120),
  email: z.string().trim().email().max(200),
  subject: z.string().trim().min(2).max(160),
  message: z.string().trim().min(10).max(4000),
});

/** Public: store a contact form submission. */
export const submitContactMessage = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => contactSchema.parse(input))
  .handler(async ({ data }) => {
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
    const supabasePublic = createClient<Database>(process.env["SUPABASE_URL"]!, key, {
      auth: { persistSession: false, autoRefreshToken: false, storage: undefined },
      global: {
        fetch: (input, init) => {
          const h = new Headers(init?.headers);
          if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) {
            h.delete("Authorization");
          }
          h.set("apikey", key);
          return fetch(input, { ...init, headers: h });
        },
      },
    });

    const { error } = await supabasePublic.from("contact_submissions").insert({
      name: data.name,
      email: data.email,
      subject: data.subject,
      message: data.message,
    });

    if (error) return { ok: false as const, error: "Your message could not be sent. Please try again." };
    return { ok: true as const };
  });

export interface ContactSubmission {
  id: string;
  createdAt: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  handled: boolean;
}

/** Admin: list contact form submissions. */
export const listContactSubmissions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (isAdmin !== true) return { ok: false as const, error: "Admins only." };

    const { data, error } = await context.supabase
      .from("contact_submissions")
      .select("id, created_at, name, email, subject, message, handled")
      .order("created_at", { ascending: false })
      .limit(300);
    if (error) return { ok: false as const, error: "Could not load messages." };

    const submissions: ContactSubmission[] = (data ?? []).map((row) => ({
      id: row.id,
      createdAt: row.created_at,
      name: row.name,
      email: row.email,
      subject: row.subject,
      message: row.message,
      handled: row.handled,
    }));
    return { ok: true as const, submissions };
  });

/** Admin: mark a contact message as handled or unhandled. */
export const setContactHandled = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ id: z.string().uuid(), handled: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (isAdmin !== true) return { ok: false as const, error: "Admins only." };

    const { error } = await context.supabase
      .from("contact_submissions")
      .update({ handled: data.handled })
      .eq("id", data.id);
    if (error) return { ok: false as const, error: "Could not update the message." };
    return { ok: true as const };
  });
