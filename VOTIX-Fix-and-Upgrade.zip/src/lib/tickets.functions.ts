import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export interface MyTicket {
  id: string;
  ticketCode: string;
  checkedIn: boolean;
  createdAt: string;
  tierName: string;
  eventTitle: string;
  eventSlug: string;
  eventStartsAt: string;
  eventVenue: string;
  eventCity: string;
  eventImage: string | null;
}

export const listMyTickets = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<{ tickets: MyTicket[] }> => {
    const { data, error } = await context.supabase
      .from("tickets")
      .select(
        "id, ticket_code, checked_in, created_at, ticket_tiers(name), events(title, slug, starts_at, venue, city, image_url)",
      )
      .eq("owner_id", context.userId)
      .order("created_at", { ascending: false });

    if (error) throw new Error(error.message);

    const rows = (data ?? []) as unknown as Array<{
      id: string;
      ticket_code: string;
      checked_in: boolean;
      created_at: string;
      ticket_tiers: { name: string } | null;
      events: {
        title: string;
        slug: string;
        starts_at: string;
        venue: string;
        city: string;
        image_url: string | null;
      } | null;
    }>;

    return {
      tickets: rows.map((row) => ({
        id: row.id,
        ticketCode: row.ticket_code,
        checkedIn: row.checked_in,
        createdAt: row.created_at,
        tierName: row.ticket_tiers?.name ?? "Ticket",
        eventTitle: row.events?.title ?? "Event",
        eventSlug: row.events?.slug ?? "",
        eventStartsAt: row.events?.starts_at ?? row.created_at,
        eventVenue: row.events?.venue ?? "",
        eventCity: row.events?.city ?? "",
        eventImage: row.events?.image_url ?? null,
      })),
    };
  });
