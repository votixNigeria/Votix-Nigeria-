import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const castVote = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({ categoryId: z.string().uuid(), nomineeId: z.string().uuid() })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: category } = await context.supabase
      .from("vote_categories")
      .select("id, events(voting_status)")
      .eq("id", data.categoryId)
      .maybeSingle();

    const status = (category as unknown as { events?: { voting_status?: string } } | null)?.events
      ?.voting_status;
    if (!category || status !== "open") {
      return { ok: false as const, error: "Voting is not open for this event." };
    }

    const { error } = await context.supabase.from("votes").insert({
      user_id: context.userId,
      category_id: data.categoryId,
      nominee_id: data.nomineeId,
    });

    if (error) {
      if (error.code === "23505") {
        return { ok: false as const, error: "You have already voted in this category." };
      }
      return { ok: false as const, error: "Could not record your vote." };
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error: countError } = await supabaseAdmin.rpc("increment_nominee_votes", {
      _nominee_id: data.nomineeId,
    });
    if (countError) console.error("[votes] counter update failed", countError.message);

    return { ok: true as const };
  });

export const myVotesForEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ categoryIds: z.array(z.string().uuid()).max(50) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    if (data.categoryIds.length === 0) return { votes: {} as Record<string, string> };
    const { data: rows } = await context.supabase
      .from("votes")
      .select("category_id, nominee_id")
      .eq("user_id", context.userId)
      .in("category_id", data.categoryIds);
    const votes: Record<string, string> = {};
    for (const row of rows ?? []) votes[row.category_id] = row.nominee_id;
    return { votes };
  });
