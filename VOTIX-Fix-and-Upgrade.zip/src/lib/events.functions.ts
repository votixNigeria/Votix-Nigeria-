import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";
import type { EventRow } from "@/data/events";

const EVENT_FIELDS =
  "id, slug, title, category, organizer_name, image_url, starts_at, ends_at, venue, city, currency, description, voting_status, voting_closes_at";
const TIER_FIELDS = "id, name, description, price, available, position, event_id";
const CATEGORY_FIELDS = "id, name, position, event_id";
const NOMINEE_FIELDS = "id, name, subtitle, votes, category_id";

function publicClient() {
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  const url = process.env["SUPABASE_URL"];
  if (!key || !url) throw new Error("VOTIX is missing its Supabase server configuration.");
  return createClient<Database>(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

async function hydrateEvents(rows: any[], client: ReturnType<typeof publicClient>) {
  const ids = rows.map((r) => r.id);
  if (!ids.length) return [] as EventRow[];
  const [{ data: tiers, error: tierError }, { data: cats, error: catError }] = await Promise.all([
    client.from("ticket_tiers").select(TIER_FIELDS).in("event_id", ids).order("position", { ascending: true }),
    client.from("vote_categories").select(CATEGORY_FIELDS).in("event_id", ids).order("position", { ascending: true }),
  ]);
  if (tierError) throw tierError;
  if (catError) throw catError;
  const catIds = (cats ?? []).map((c) => c.id);
  const { data: nominees, error: nomineeError } = catIds.length
    ? await client.from("vote_nominees").select(NOMINEE_FIELDS).in("category_id", catIds)
    : { data: [], error: null };
  if (nomineeError) throw nomineeError;
  const tierMap = new Map<string, any[]>();
  for (const t of tiers ?? []) tierMap.set(t.event_id, [...(tierMap.get(t.event_id) ?? []), t]);
  const catMap = new Map<string, any[]>();
  for (const c of cats ?? []) catMap.set(c.event_id, [...(catMap.get(c.event_id) ?? []), { ...c, vote_nominees: (nominees ?? []).filter((n) => n.category_id === c.id) }]);
  return rows.map((r) => ({ ...r, ticket_tiers: tierMap.get(r.id) ?? [], vote_categories: catMap.get(r.id) ?? [] })) as EventRow[];
}

export const listPublicEvents = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const client = publicClient();
    const { data, error } = await client.from("events").select(EVENT_FIELDS).eq("published", true).order("starts_at", { ascending: true });
    if (error) throw error;
    return { events: await hydrateEvents(data ?? [], client), error: null };
  } catch (error) {
    console.error("[events] list failed", error);
    return { events: [] as EventRow[], error: "Could not load events right now." };
  }
});

export const getPublicEvent = createServerFn({ method: "GET" })
  .inputValidator((input: unknown) => z.object({ slug: z.string().min(1).max(100) }).parse(input))
  .handler(async ({ data }) => {
    try {
      const client = publicClient();
      const { data: row, error } = await client.from("events").select(EVENT_FIELDS).eq("slug", data.slug).eq("published", true).maybeSingle();
      if (error || !row) return { event: null };
      const [event] = await hydrateEvents([row], client);
      return { event: event ?? null };
    } catch (error) {
      console.error("[events] detail failed", error);
      return { event: null };
    }
  });
