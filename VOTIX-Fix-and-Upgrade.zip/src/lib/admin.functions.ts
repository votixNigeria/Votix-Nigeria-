import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** True when the signed-in caller holds the admin role. */
export const amIAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    return { isAdmin: data === true };
  });

export interface AdminTransaction {
  id: string;
  createdAt: string;
  status: string;
  quantity: number;
  total: number;
  currency: string;
  provider: string;
  reference: string | null;
  buyerEmail: string;
  buyerName: string;
  eventTitle: string;
  eventSlug: string;
  tierName: string;
  ticketsIssued: number;
}

/** Full transaction audit list for admins only. */
export const listAllTransactions = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        search: z.string().max(120).optional(),
        status: z.enum(["all", "pending", "paid", "failed"]).optional(),
      })
      .parse(input ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (isAdmin !== true) {
      return { ok: false as const, error: "Admins only." };
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    let query = supabaseAdmin
      .from("orders")
      .select(
        "id, created_at, status, quantity, total, currency, provider, provider_reference, buyer_email, buyer_id, events(title, slug), ticket_tiers(name), tickets(id)",
      )
      .order("created_at", { ascending: false })
      .limit(500);

    if (data.status && data.status !== "all") query = query.eq("status", data.status);

    const { data: rows, error } = await query;
    if (error) return { ok: false as const, error: "Could not load transactions." };

    const buyerIds = Array.from(new Set((rows ?? []).map((r) => r.buyer_id)));
    const { data: profiles } = buyerIds.length
      ? await supabaseAdmin.from("profiles").select("id, full_name").in("id", buyerIds)
      : { data: [] as { id: string; full_name: string | null }[] };
    const names = new Map((profiles ?? []).map((p) => [p.id, p.full_name ?? ""]));

    const term = (data.search ?? "").trim().toLowerCase();

    const transactions: AdminTransaction[] = (rows ?? [])
      .map((row) => {
        const event = row.events as { title: string; slug: string } | null;
        const tier = row.ticket_tiers as { name: string } | null;
        const tickets = (row.tickets ?? []) as { id: string }[];
        return {
          id: row.id,
          createdAt: row.created_at,
          status: row.status,
          quantity: row.quantity,
          total: Number(row.total),
          currency: row.currency,
          provider: row.provider,
          reference: row.provider_reference,
          buyerEmail: row.buyer_email ?? "",
          buyerName: names.get(row.buyer_id) ?? "",
          eventTitle: event?.title ?? "Deleted event",
          eventSlug: event?.slug ?? "",
          tierName: tier?.name ?? "—",
          ticketsIssued: tickets.length,
        };
      })
      .filter((t) =>
        term
          ? [t.buyerEmail, t.buyerName, t.eventTitle, t.reference ?? "", t.id]
              .join(" ")
              .toLowerCase()
              .includes(term)
          : true,
      );

    const paid = transactions.filter((t) => t.status === "paid");
    return {
      ok: true as const,
      transactions,
      totals: {
        count: transactions.length,
        paidCount: paid.length,
        pendingCount: transactions.filter((t) => t.status === "pending").length,
        failedCount: transactions.filter((t) => t.status === "failed").length,
        grossPaid: paid.reduce((sum, t) => sum + t.total, 0),
        ticketsIssued: paid.reduce((sum, t) => sum + t.ticketsIssued, 0),
      },
    };
  });

async function requireAdmin(context: any) {
  const { data: isAdmin } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  return isAdmin === true;
}

/** Platform-wide headline numbers for the admin overview tab. */
export const adminOverview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    if (!(await requireAdmin(context))) return { ok: false as const, error: "Admins only." };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const count = async (table: string) => {
      const { count: c } = await supabaseAdmin
        .from(table as "orders")
        .select("id", { count: "exact", head: true });
      return c ?? 0;
    };

    const [users, events, publishedEvents, tickets, votes, orders, paidOrders] =
      await Promise.all([
        count("profiles"),
        count("events"),
        supabaseAdmin
          .from("events")
          .select("id", { count: "exact", head: true })
          .eq("published", true)
          .then((r) => r.count ?? 0),
        count("tickets"),
        count("votes"),
        count("orders"),
        supabaseAdmin
          .from("orders")
          .select("total")
          .eq("status", "paid")
          .then((r) => r.data ?? []),
      ]);

    return {
      ok: true as const,
      overview: {
        users,
        events,
        publishedEvents,
        tickets,
        votes,
        orders,
        grossPaid: paidOrders.reduce((sum, o) => sum + Number(o.total), 0),
      },
    };
  });

export interface AdminEvent {
  id: string;
  slug: string;
  title: string;
  category: string;
  startsAt: string;
  venue: string;
  isPublished: boolean;
  votingOpen: boolean;
  organizerId: string;
  organizerName: string;
  orderCount: number;
  ticketCount: number;
}

/** Every event on the platform, with per-event sales counts. */
export const listAllEventsAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    if (!(await requireAdmin(context))) return { ok: false as const, error: "Admins only." };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows, error } = await supabaseAdmin
      .from("events")
      .select(
        "id, slug, title, category, starts_at, venue, published, voting_status, organizer_id, orders(id), tickets(id)",
      )
      .order("starts_at", { ascending: false });
    if (error) return { ok: false as const, error: "Could not load events." };

    const organizerIds = Array.from(new Set((rows ?? []).map((r) => r.organizer_id)));
    const { data: profiles } = organizerIds.length
      ? await supabaseAdmin.from("profiles").select("id, full_name").in("id", organizerIds)
      : { data: [] as { id: string; full_name: string | null }[] };
    const names = new Map((profiles ?? []).map((p) => [p.id, p.full_name ?? ""]));

    const events: AdminEvent[] = (rows ?? []).map((row) => ({
      id: row.id,
      slug: row.slug,
      title: row.title,
      category: row.category,
      startsAt: row.starts_at,
      venue: row.venue,
      isPublished: row.published,
      votingOpen: row.voting_status === "open",
      organizerId: row.organizer_id,
      organizerName: names.get(row.organizer_id) ?? "",
      orderCount: ((row.orders ?? []) as { id: string }[]).length,
      ticketCount: ((row.tickets ?? []) as { id: string }[]).length,
    }));
    return { ok: true as const, events };
  });

/** Admin control: publish or unpublish any event. */
export const setEventPublishedAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ eventId: z.string().uuid(), publish: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    if (!(await requireAdmin(context))) return { ok: false as const, error: "Admins only." };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("events")
      .update({ published: data.publish })
      .eq("id", data.eventId);
    if (error) return { ok: false as const, error: "Could not update the event." };
    return { ok: true as const };
  });

/** Admin control: open or close voting on any event. */
export const setEventVotingAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ eventId: z.string().uuid(), open: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    if (!(await requireAdmin(context))) return { ok: false as const, error: "Admins only." };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("events")
      .update({ voting_status: data.open ? "open" : "closed" })
      .eq("id", data.eventId);
    if (error) return { ok: false as const, error: "Could not update voting." };
    return { ok: true as const };
  });

/** Admin control: permanently remove an event and its data. */
export const deleteEventAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ eventId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    if (!(await requireAdmin(context))) return { ok: false as const, error: "Admins only." };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("events").delete().eq("id", data.eventId);
    if (error) return { ok: false as const, error: "Could not delete the event." };
    return { ok: true as const };
  });

export interface AdminUser {
  id: string;
  createdAt: string;
  fullName: string;
  roles: string[];
  orderCount: number;
  totalSpent: number;
}

/** Every registered account with their roles and spend. */
export const listAllUsersAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    if (!(await requireAdmin(context))) return { ok: false as const, error: "Admins only." };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const [{ data: profiles }, { data: roles }, { data: paidOrders }] = await Promise.all([
      supabaseAdmin
        .from("profiles")
        .select("id, full_name, created_at")
        .order("created_at", { ascending: false })
        .limit(500),
      supabaseAdmin.from("user_roles").select("user_id, role"),
      supabaseAdmin.from("orders").select("buyer_id, total").eq("status", "paid"),
    ]);

    const roleMap = new Map<string, string[]>();
    for (const r of roles ?? []) {
      const list = roleMap.get(r.user_id) ?? [];
      list.push(r.role);
      roleMap.set(r.user_id, list);
    }
    const spendMap = new Map<string, { count: number; total: number }>();
    for (const o of paidOrders ?? []) {
      const cur = spendMap.get(o.buyer_id) ?? { count: 0, total: 0 };
      cur.count += 1;
      cur.total += Number(o.total);
      spendMap.set(o.buyer_id, cur);
    }

    const users: AdminUser[] = (profiles ?? []).map((p) => ({
      id: p.id,
      createdAt: p.created_at,
      fullName: p.full_name ?? "",
      roles: roleMap.get(p.id) ?? [],
      orderCount: spendMap.get(p.id)?.count ?? 0,
      totalSpent: spendMap.get(p.id)?.total ?? 0,
    }));
    return { ok: true as const, users };
  });

export interface AdminWallet {
  userId: string;
  fullName: string;
  availableBalance: number;
  pendingBalance: number;
  currency: string;
  updatedAt: string;
}

/** Lists organiser/user wallet balances for controlled admin adjustments. */
export const listAdminWallets = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    if (!(await requireAdmin(context))) return { ok: false as const, error: "Admins only." };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    const [{ data: wallets, error }, { data: profiles }] = await Promise.all([
      db.from("wallets").select("user_id, available_balance, pending_balance, currency, updated_at").order("updated_at", { ascending: false }).limit(500),
      db.from("profiles").select("id, full_name").limit(1000),
    ]);
    if (error) return { ok: false as const, error: "Could not load wallet balances." };
    const names = new Map((profiles ?? []).map((p: any) => [p.id, p.full_name ?? ""]));
    return {
      ok: true as const,
      wallets: (wallets ?? []).map((w: any) => ({
        userId: w.user_id,
        fullName: names.get(w.user_id) ?? "",
        availableBalance: Number(w.available_balance),
        pendingBalance: Number(w.pending_balance),
        currency: w.currency || "NGN",
        updatedAt: w.updated_at,
      })) as AdminWallet[],
    };
  });

/** Admin-only balance control. Positive adjustment credits; negative adjustment debits. */
export const adjustUserBalance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({
    userId: z.string().uuid(),
    amount: z.number().finite().refine((n) => n !== 0, "Amount cannot be zero."),
    description: z.string().min(3).max(240),
  }).parse(input))
  .handler(async ({ data, context }) => {
    if (!(await requireAdmin(context))) return { ok: false as const, error: "Admins only." };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    const { error } = await db.rpc("admin_adjust_balance", {
      _user_id: data.userId,
      _amount: data.amount,
      _description: data.description,
      _admin_id: context.userId,
    });
    if (error) return { ok: false as const, error: error.message || "Could not adjust balance." };
    return { ok: true as const };
  });

/** Admin-only exact balance setter. */
export const setUserBalance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({
    userId: z.string().uuid(),
    amount: z.number().finite().min(0),
    description: z.string().min(3).max(240),
  }).parse(input))
  .handler(async ({ data, context }) => {
    if (!(await requireAdmin(context))) return { ok: false as const, error: "Admins only." };
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const db = supabaseAdmin as any;
    const { error } = await db.rpc("admin_set_balance", {
      _user_id: data.userId,
      _amount: data.amount,
      _description: data.description,
      _admin_id: context.userId,
    });
    if (error) return { ok: false as const, error: error.message || "Could not set balance." };
    return { ok: true as const };
  });
