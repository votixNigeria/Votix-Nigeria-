import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { EventRow } from "@/data/events";

const SELECT =
  "id, slug, title, category, organizer_name, image_url, starts_at, ends_at, venue, city, currency, description, voting_status, voting_closes_at, published, ticket_tiers(id, name, description, price, available, position), vote_categories(id, name, position, vote_nominees(id, name, subtitle, votes))";

const tierSchema = z.object({
  name: z.string().min(1).max(80),
  description: z.string().max(300).default(""),
  price: z.number().min(0).max(100_000_000),
});

const categorySchema = z.object({
  name: z.string().min(1).max(120),
  nominees: z
    .array(
      z.object({
        name: z.string().min(1).max(120),
        subtitle: z.string().max(160).default(""),
      }),
    )
    .max(30)
    .default([]),
});

const createSchema = z.object({
  title: z.string().min(3).max(140),
  slug: z.string().min(3).max(80),
  category: z.string().min(1).max(40),
  organizerName: z.string().min(1).max(120),
  imageUrl: z.string().url().max(600).optional().or(z.literal("")),
  startsAt: z.string().min(1),
  endsAt: z.string().optional().or(z.literal("")),
  venue: z.string().min(1).max(160),
  city: z.string().min(1).max(80),
  currency: z.string().min(1).max(8).default("₦"),
  description: z.string().max(4000).default(""),
  votingStatus: z.enum(["none", "open", "closed"]).default("none"),
  votingClosesAt: z.string().optional().or(z.literal("")),
  published: z.boolean().default(true),
  tiers: z.array(tierSchema).min(1).max(12),
  voteCategories: z.array(categorySchema).max(12).default([]),
});

export const listMyEvents = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("events")
      .select(SELECT)
      .eq("organizer_id", context.userId)
      .order("starts_at", { ascending: true });
    if (error) throw new Error(error.message);
    return { events: (data ?? []) as unknown as EventRow[] };
  });

export const listMyEventSales = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("orders")
      .select("id, event_id, quantity, total, currency, status, buyer_email, created_at")
      .eq("status", "paid")
      .in(
        "event_id",
        (
          await context.supabase.from("events").select("id").eq("organizer_id", context.userId)
        ).data?.map((event) => event.id) ?? [],
      )
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) throw new Error(error.message);
    return { orders: data ?? [] };
  });

export const createEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => createSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    await supabase.from("user_roles").insert({ user_id: userId, role: "organizer" });

    const { data: event, error } = await supabase
      .from("events")
      .insert({
        organizer_id: userId,
        slug: data.slug,
        title: data.title,
        category: data.category,
        organizer_name: data.organizerName,
        image_url: data.imageUrl || null,
        starts_at: data.startsAt,
        ends_at: data.endsAt || null,
        venue: data.venue,
        city: data.city,
        currency: data.currency,
        description: data.description,
        voting_status: data.votingStatus,
        voting_closes_at: data.votingClosesAt || null,
        published: data.published,
      })
      .select("id, slug")
      .single();
    if (error) throw new Error(error.message);

    const { error: tierError } = await supabase.from("ticket_tiers").insert(
      data.tiers.map((tier, index) => ({
        event_id: event.id,
        name: tier.name,
        description: tier.description,
        price: tier.price,
        position: index,
      })),
    );
    if (tierError) throw new Error(tierError.message);

    for (const [index, category] of data.voteCategories.entries()) {
      const { data: cat, error: catError } = await supabase
        .from("vote_categories")
        .insert({ event_id: event.id, name: category.name, position: index })
        .select("id")
        .single();
      if (catError) throw new Error(catError.message);
      if (category.nominees.length > 0) {
        const { error: nomError } = await supabase.from("vote_nominees").insert(
          category.nominees.map((n) => ({
            category_id: cat.id,
            name: n.name,
            subtitle: n.subtitle,
          })),
        );
        if (nomError) throw new Error(nomError.message);
      }
    }

    return { id: event.id, slug: event.slug };
  });

export const updateEventVoting = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        eventId: z.string().uuid(),
        votingStatus: z.enum(["none", "open", "closed"]),
        votingClosesAt: z.string().optional().or(z.literal("")),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("events")
      .update({
        voting_status: data.votingStatus,
        voting_closes_at: data.votingClosesAt || null,
      })
      .eq("id", data.eventId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const setEventPublished = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ eventId: z.string().uuid(), published: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("events")
      .update({ published: data.published })
      .eq("id", data.eventId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const addTicketTier = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ eventId: z.string().uuid(), tier: tierSchema, position: z.number() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("ticket_tiers").insert({
      event_id: data.eventId,
      name: data.tier.name,
      description: data.tier.description,
      price: data.tier.price,
      position: data.position,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const setTierAvailability = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ tierId: z.string().uuid(), available: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("ticket_tiers")
      .update({ available: data.available })
      .eq("id", data.tierId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const addVoteCategory = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({ eventId: z.string().uuid(), category: categorySchema, position: z.number() })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: cat, error } = await context.supabase
      .from("vote_categories")
      .insert({ event_id: data.eventId, name: data.category.name, position: data.position })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    if (data.category.nominees.length > 0) {
      const { error: nomError } = await context.supabase.from("vote_nominees").insert(
        data.category.nominees.map((n) => ({
          category_id: cat.id,
          name: n.name,
          subtitle: n.subtitle,
        })),
      );
      if (nomError) throw new Error(nomError.message);
    }
    return { ok: true };
  });

export const addNominee = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        categoryId: z.string().uuid(),
        name: z.string().min(1).max(120),
        subtitle: z.string().max(160).default(""),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("vote_nominees").insert({
      category_id: data.categoryId,
      name: data.name,
      subtitle: data.subtitle,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
