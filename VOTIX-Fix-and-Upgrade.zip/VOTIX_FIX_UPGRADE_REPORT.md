# VOTIX Fix & Upgrade Report

## Release
VOTIX Fix & Upgrade — September 2026

## Fixed / improved

### 1. Public Events reliability
The old public event query requested several nested relationships in one PostgREST select. The upgraded version loads the base event rows first, then ticket tiers, voting categories and nominees separately and assembles the same `EventRow` shape. This makes the Events page much less sensitive to relationship/schema changes.

It also catches missing Supabase server configuration instead of allowing an unhandled server exception to become a generic 500.

### 2. Create Event flow
`/create-event` no longer claims the builder is still being built. It now sends organisers to the existing authenticated builder, which already supports:
- event details
- dates/venue/city
- banner URL
- ticket tiers
- voting status
- voting categories
- nominees
- publish action

### 3. Paystack verification
The callback now verifies the Paystack transaction amount and currency against the stored order before changing the order to `paid` and issuing tickets.

### 4. Voting concurrency
Vote counters previously used read-then-write logic (`votes + 1`), which can lose increments when simultaneous votes arrive. A database-side atomic increment function is now used.

### 5. Admin wallet control
A Wallets tab was added to the admin dashboard. Admins can select a user, enter a positive or negative amount, and provide an audit reason. The server checks the admin role and the database function prevents the balance from going below zero.

Wallet history is stored in `wallet_transactions`.

## Still required in production

1. Apply all Supabase migrations, including the new wallet migration.
2. Confirm Vercel has the required Supabase variables.
3. Set `PAYSTACK_SECRET_KEY` in Vercel for live checkout.
4. Confirm Supabase Auth redirect/site URLs use `https://www.votixnigeria.com` and the actual deployed callback URL.
5. Test the full payment path with a Paystack test transaction before switching to live keys.

## Recommended next upgrade

Add organiser revenue settlement/withdrawals, QR scanner/check-in, ticket PDF/QR rendering, admin refund controls, and event editing/deletion with a full audit log.
