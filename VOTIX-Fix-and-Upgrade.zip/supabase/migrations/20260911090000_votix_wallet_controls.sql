CREATE TABLE public.wallets (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  available_balance numeric(14,2) NOT NULL DEFAULT 0 CHECK (available_balance >= 0),
  pending_balance numeric(14,2) NOT NULL DEFAULT 0 CHECK (pending_balance >= 0),
  currency text NOT NULL DEFAULT 'NGN',
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.wallet_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount numeric(14,2) NOT NULL,
  balance_after numeric(14,2) NOT NULL,
  type text NOT NULL CHECK (type IN ('credit','debit','admin_set','withdrawal','refund','commission')),
  description text NOT NULL DEFAULT '',
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.wallets TO authenticated;
GRANT SELECT ON public.wallet_transactions TO authenticated;
GRANT ALL ON public.wallets, public.wallet_transactions TO service_role;
CREATE POLICY "wallet_self_read" ON public.wallets FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "wallet_transactions_self_read" ON public.wallet_transactions FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE INDEX wallet_transactions_user_idx ON public.wallet_transactions(user_id, created_at DESC);

CREATE OR REPLACE FUNCTION public.ensure_wallet(_user_id uuid)
RETURNS public.wallets LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE w public.wallets;
BEGIN
  INSERT INTO public.wallets(user_id) VALUES (_user_id) ON CONFLICT (user_id) DO NOTHING;
  SELECT * INTO w FROM public.wallets WHERE user_id = _user_id;
  RETURN w;
END;
$$;
REVOKE ALL ON FUNCTION public.ensure_wallet(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.ensure_wallet(uuid) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.admin_adjust_balance(_user_id uuid, _amount numeric, _description text, _admin_id uuid)
RETURNS public.wallets LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE w public.wallets;
BEGIN
  IF NOT public.has_role(_admin_id, 'admin') THEN RAISE EXCEPTION 'Admins only'; END IF;
  IF _amount = 0 THEN RAISE EXCEPTION 'Amount cannot be zero'; END IF;
  INSERT INTO public.wallets(user_id) VALUES (_user_id) ON CONFLICT (user_id) DO NOTHING;
  UPDATE public.wallets
  SET available_balance = available_balance + _amount, updated_at = now()
  WHERE user_id = _user_id AND available_balance + _amount >= 0
  RETURNING * INTO w;
  IF NOT FOUND THEN RAISE EXCEPTION 'Insufficient balance'; END IF;
  INSERT INTO public.wallet_transactions(user_id, amount, balance_after, type, description, created_by)
  VALUES (_user_id, _amount, w.available_balance, CASE WHEN _amount > 0 THEN 'credit' ELSE 'debit' END, _description, _admin_id);
  RETURN w;
END;
$$;
REVOKE ALL ON FUNCTION public.admin_adjust_balance(uuid, numeric, text, uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_adjust_balance(uuid, numeric, text, uuid) TO service_role;

CREATE OR REPLACE FUNCTION public.increment_nominee_votes(_nominee_id uuid)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE next_votes integer;
BEGIN
  UPDATE public.vote_nominees SET votes = votes + 1 WHERE id = _nominee_id RETURNING votes INTO next_votes;
  IF NOT FOUND THEN RAISE EXCEPTION 'Nominee not found'; END IF;
  RETURN next_votes;
END;
$$;
REVOKE ALL ON FUNCTION public.increment_nominee_votes(uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.increment_nominee_votes(uuid) TO service_role;

CREATE OR REPLACE FUNCTION public.admin_set_balance(_user_id uuid, _amount numeric, _description text, _admin_id uuid)
RETURNS public.wallets LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE w public.wallets;
DECLARE delta numeric;
BEGIN
  IF NOT public.has_role(_admin_id, 'admin') THEN RAISE EXCEPTION 'Admins only'; END IF;
  IF _amount < 0 THEN RAISE EXCEPTION 'Balance cannot be negative'; END IF;
  INSERT INTO public.wallets(user_id) VALUES (_user_id) ON CONFLICT (user_id) DO NOTHING;
  SELECT * INTO w FROM public.wallets WHERE user_id = _user_id FOR UPDATE;
  delta := _amount - w.available_balance;
  UPDATE public.wallets SET available_balance = _amount, updated_at = now() WHERE user_id = _user_id RETURNING * INTO w;
  INSERT INTO public.wallet_transactions(user_id, amount, balance_after, type, description, created_by)
  VALUES (_user_id, delta, w.available_balance, 'admin_set', _description, _admin_id);
  RETURN w;
END;
$$;
REVOKE ALL ON FUNCTION public.admin_set_balance(uuid, numeric, text, uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.admin_set_balance(uuid, numeric, text, uuid) TO service_role;
