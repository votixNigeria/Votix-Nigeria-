CREATE TYPE public.app_role AS ENUM ('admin','organizer','attendee');
CREATE TYPE public.voting_status AS ENUM ('none','open','closed');
CREATE TYPE public.order_status AS ENUM ('pending','paid','failed');

CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.profiles TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles_public_read" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "profiles_self_write" ON public.profiles FOR ALL TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT, INSERT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "user_roles_self_read" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "user_roles_self_insert" ON public.user_roles FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id AND role <> 'admin');

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (NEW.id, NEW.raw_user_meta_data ->> 'full_name')
  ON CONFLICT (id) DO NOTHING;
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'attendee')
  ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TABLE public.events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organizer_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  slug text NOT NULL UNIQUE,
  title text NOT NULL,
  category text NOT NULL DEFAULT 'Concert',
  organizer_name text NOT NULL DEFAULT '',
  image_url text,
  starts_at timestamptz NOT NULL,
  ends_at timestamptz,
  venue text NOT NULL DEFAULT '',
  city text NOT NULL DEFAULT '',
  currency text NOT NULL DEFAULT 'NGN',
  description text NOT NULL DEFAULT '',
  voting_status public.voting_status NOT NULL DEFAULT 'none',
  voting_closes_at timestamptz,
  published boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.events TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.events TO authenticated;
GRANT ALL ON public.events TO service_role;
ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "events_public_read" ON public.events FOR SELECT USING (published = true);
CREATE POLICY "events_owner_read" ON public.events FOR SELECT TO authenticated USING (auth.uid() = organizer_id);
CREATE POLICY "events_owner_insert" ON public.events FOR INSERT TO authenticated WITH CHECK (auth.uid() = organizer_id);
CREATE POLICY "events_owner_update" ON public.events FOR UPDATE TO authenticated USING (auth.uid() = organizer_id) WITH CHECK (auth.uid() = organizer_id);
CREATE POLICY "events_owner_delete" ON public.events FOR DELETE TO authenticated USING (auth.uid() = organizer_id);
CREATE TRIGGER events_updated_at BEFORE UPDATE ON public.events FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE OR REPLACE FUNCTION public.owns_event(_event_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.events e WHERE e.id = _event_id AND e.organizer_id = auth.uid())
$$;

CREATE OR REPLACE FUNCTION public.event_is_public(_event_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.events e WHERE e.id = _event_id AND e.published = true)
$$;

CREATE TABLE public.ticket_tiers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  price numeric(12,2) NOT NULL DEFAULT 0,
  available boolean NOT NULL DEFAULT true,
  position int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.ticket_tiers TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.ticket_tiers TO authenticated;
GRANT ALL ON public.ticket_tiers TO service_role;
ALTER TABLE public.ticket_tiers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tiers_public_read" ON public.ticket_tiers FOR SELECT USING (public.event_is_public(event_id));
CREATE POLICY "tiers_owner_all" ON public.ticket_tiers FOR ALL TO authenticated USING (public.owns_event(event_id)) WITH CHECK (public.owns_event(event_id));

CREATE TABLE public.vote_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  name text NOT NULL,
  position int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.vote_categories TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vote_categories TO authenticated;
GRANT ALL ON public.vote_categories TO service_role;
ALTER TABLE public.vote_categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "vote_categories_public_read" ON public.vote_categories FOR SELECT USING (public.event_is_public(event_id));
CREATE POLICY "vote_categories_owner_all" ON public.vote_categories FOR ALL TO authenticated USING (public.owns_event(event_id)) WITH CHECK (public.owns_event(event_id));

CREATE TABLE public.vote_nominees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid NOT NULL REFERENCES public.vote_categories(id) ON DELETE CASCADE,
  name text NOT NULL,
  subtitle text NOT NULL DEFAULT '',
  votes int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.vote_nominees TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vote_nominees TO authenticated;
GRANT ALL ON public.vote_nominees TO service_role;
ALTER TABLE public.vote_nominees ENABLE ROW LEVEL SECURITY;
CREATE POLICY "vote_nominees_public_read" ON public.vote_nominees FOR SELECT USING (true);
CREATE POLICY "vote_nominees_owner_all" ON public.vote_nominees FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.vote_categories c WHERE c.id = category_id AND public.owns_event(c.event_id)))
  WITH CHECK (EXISTS (SELECT 1 FROM public.vote_categories c WHERE c.id = category_id AND public.owns_event(c.event_id)));

CREATE TABLE public.votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  category_id uuid NOT NULL REFERENCES public.vote_categories(id) ON DELETE CASCADE,
  nominee_id uuid NOT NULL REFERENCES public.vote_nominees(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, category_id)
);
GRANT SELECT, INSERT ON public.votes TO authenticated;
GRANT ALL ON public.votes TO service_role;
ALTER TABLE public.votes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "votes_self_read" ON public.votes FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "votes_self_insert" ON public.votes FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  buyer_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  event_id uuid NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  tier_id uuid NOT NULL REFERENCES public.ticket_tiers(id) ON DELETE RESTRICT,
  quantity int NOT NULL CHECK (quantity > 0 AND quantity <= 10),
  unit_price numeric(12,2) NOT NULL,
  total numeric(12,2) NOT NULL,
  currency text NOT NULL DEFAULT 'NGN',
  status public.order_status NOT NULL DEFAULT 'pending',
  provider text NOT NULL DEFAULT 'paystack',
  provider_reference text UNIQUE,
  buyer_email text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.orders TO authenticated;
GRANT ALL ON public.orders TO service_role;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "orders_self_read" ON public.orders FOR SELECT TO authenticated USING (auth.uid() = buyer_id);
CREATE POLICY "orders_organizer_read" ON public.orders FOR SELECT TO authenticated USING (public.owns_event(event_id));
CREATE TRIGGER orders_updated_at BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  event_id uuid NOT NULL REFERENCES public.events(id) ON DELETE CASCADE,
  tier_id uuid NOT NULL REFERENCES public.ticket_tiers(id) ON DELETE RESTRICT,
  owner_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  ticket_code text NOT NULL UNIQUE,
  checked_in boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.tickets TO authenticated;
GRANT ALL ON public.tickets TO service_role;
ALTER TABLE public.tickets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "tickets_self_read" ON public.tickets FOR SELECT TO authenticated USING (auth.uid() = owner_id);
CREATE POLICY "tickets_organizer_read" ON public.tickets FOR SELECT TO authenticated USING (public.owns_event(event_id));

CREATE INDEX events_starts_at_idx ON public.events (starts_at);
CREATE INDEX ticket_tiers_event_idx ON public.ticket_tiers (event_id);
CREATE INDEX orders_buyer_idx ON public.orders (buyer_id);
CREATE INDEX tickets_owner_idx ON public.tickets (owner_id);